package Assignment1;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

public class RegistrationServiceImpl implements RegistrationService {
    private final RegistrationRepository repo;
    private final ApplicationService    appSvc;
    private final ProjectService        projSvc;

    public RegistrationServiceImpl(RegistrationRepository repo,
                                   ApplicationService appSvc,
                                   ProjectService projSvc) {
        this.repo    = repo;
        this.appSvc  = appSvc;
        this.projSvc = projSvc;
    }

    @Override
    public boolean canRegisterOfficer(String nric) {
        try {
            // 1) cannot register if they ever applied as an applicant
            boolean appliedAsApplicant = projSvc.getAllProjects().stream()
                .anyMatch(p -> appSvc.hasApplication(nric, p.getName()));
            if (appliedAsApplicant) return false;

            // 2) cannot register if they have any pending/approved registration
            boolean hasReg = repo.load().stream()
                .anyMatch(r ->
                    r.getOfficerNric().equals(nric)
                 && r.getStatus() != RegistrationStatus.REJECTED
                );
            return !hasReg;
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
    
    


 // In RegistrationServiceImpl.java
    @Override
    public void registerOfficer(String nric, Project p) {
        try {
            if (!canRegisterOfficer(nric)) {
                throw new IllegalStateException("Already registered");
            }
            if (appSvc.hasApplication(nric, p.getName())) {
                throw new IllegalStateException(
                    "Cannot register for a project you have applied to."
                );
            }

            // 1) Create the new registration
            Registration reg = new Registration(nric, p);

            // 2) Persist it
            repo.add(reg);

            // 3) **Also add it to the project's in-memory list**
            p.getRegistrations().add(reg);

        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }


    @Override
    public List<Registration> getAllRegistrations() {
        try {
            return repo.load();
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to reload registrations.csv", e);
        }
    }

    @Override
    public boolean isOfficer(String nric, Project p) {
        // reloads every time, looks only for APPROVED slots
        return getAllRegistrations().stream()
            .filter(r -> r.getStatus() == RegistrationStatus.APPROVED)
            .anyMatch(r ->
                r.getOfficerNric().equals(nric) &&
                r.getProjectName().equals(p.getName())
            );
    }



    @Override
    public void updateStatus(String nric, String projName, boolean approved) {
        try {
            Registration r = repo.load().stream()
                .filter(x ->
                    x.getOfficerNric().equals(nric) &&
                    x.getProjectName().equals(projName)
                )
                .findFirst()
                .orElseThrow(() ->
                    new NoSuchElementException(
                        "No registration found for " + nric + " on project " + projName
                    )
                );
            r.setStatus(approved
                ? RegistrationStatus.APPROVED
                : RegistrationStatus.REJECTED
            );
            repo.update(r);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    @Override
    public boolean hasPendingRegistration(String nric) {
        try {
            return repo.load().stream()
                .anyMatch(r ->
                    r.getOfficerNric().equals(nric) &&
                    r.getStatus() == RegistrationStatus.PENDING
                );
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}

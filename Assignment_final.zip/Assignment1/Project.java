package Assignment1;

import java.time.LocalDate;
import java.util.EnumMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class Project {
    private String                name;
    private String                neighborhood;
    private String                managerNric;
    private int                   maxOfficerSlots;
    private Map<FlatType,Integer> availableUnits;
    private LocalDate             openDate, closeDate;
    private boolean               visible = true;
    private List<Application>  applications  = new ArrayList<>();
    private List<Registration> registrations = new ArrayList<>();
    private List<Enquiry>      enquiries     = new ArrayList<>();

    public Project(String name, String neighborhood,
                   int twoRoom, int threeRoom,
                   LocalDate open, LocalDate close,
                   int maxOfficerSlots) {
        this.name            = name;
        this.neighborhood    = neighborhood;
        this.openDate        = open;
        this.closeDate       = close;
        this.maxOfficerSlots = maxOfficerSlots;
        this.availableUnits  = new EnumMap<>(FlatType.class);
        this.availableUnits.put(FlatType.TWO_ROOM,   twoRoom);
        this.availableUnits.put(FlatType.THREE_ROOM, threeRoom);
    }

    public String getName()                     { return name; }
    public String getNeighborhood()             { return neighborhood; }
    public String getManagerNric()              { return managerNric; }
    public void   setManagerNric(String m)      { this.managerNric = m; }
    public int    getMaxOfficerSlots()          { return maxOfficerSlots; }
    public LocalDate getOpenDate()              { return openDate; }
    public LocalDate getCloseDate()             { return closeDate; }
    public boolean isVisible()                  { return visible; }
    public void    setVisible(boolean v)        { this.visible = v; }
    public Map<FlatType,Integer> getAvailableUnits() { return availableUnits; }

    
 // ← Add these setters so CLI can edit them:
    public void setName(String name) {
        this.name = name;
    }
    public void setNeighborhood(String neighborhood) {
        this.neighborhood = neighborhood;
    }

    public void setOpenDate(LocalDate openDate) {
        this.openDate = openDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = closeDate;
    }

    // (a setter for officer slots if you want to edit that too)
    public void setMaxOfficerSlots(int maxOfficerSlots) {
        this.maxOfficerSlots = maxOfficerSlots;
    }
    
    public void decrementUnits(FlatType type) {
        int cur = availableUnits.getOrDefault(type,0);
        if (cur <= 0) throw new IllegalArgumentException("No more " + type);
        availableUnits.put(type, cur - 1);
    }

    @Override
    public String toString() {
        return name + " @ " + neighborhood +
               " [2R:" + availableUnits.get(FlatType.TWO_ROOM) +
               ",3R:" + availableUnits.get(FlatType.THREE_ROOM) + "]";
    }
    public List<Application> getApplications() {
        return applications;
      }
      public List<Registration> getRegistrations() {
        return registrations;
      }
      public List<Enquiry> getEnquiries() {
        return enquiries;
      }
}

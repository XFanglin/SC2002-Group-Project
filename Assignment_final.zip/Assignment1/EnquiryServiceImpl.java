package Assignment1;

import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class EnquiryServiceImpl implements EnquiryService {
    private final Map<Integer, Enquiry> store = new HashMap<>();

    @Override
    public void submit(Enquiry e) {
        store.put(e.getId(), e);
    }

    @Override
    public void reply(int id, String resp) {
        Enquiry e = store.get(id);
        if (e == null) throw new NoSuchElementException("No enquiry "+id);
        e.setResponse(resp);
    }

    @Override
    public void edit(int id, String msg) {
        Enquiry e = store.get(id);
        if (e == null) throw new NoSuchElementException("No enquiry "+id);
        e.setMessage(msg);
    }

    @Override
    public void delete(int id) {
        if (store.remove(id) == null)
            throw new NoSuchElementException("No enquiry "+id);
    }
    
    
    @Override
    public List<Enquiry> getAll() {
        return new ArrayList<>(store.values());
    }
    
    @Override
    public List<Enquiry> getEnquiriesForUser(String senderNric) {
        List<Enquiry> result = new ArrayList<>();
        for (Enquiry e : store.values()) {
            if (e.getSenderNric().equals(senderNric)) {
                result.add(e);
            }
        }
        return result;
    }

}
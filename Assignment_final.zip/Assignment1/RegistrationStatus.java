package Assignment1;


public enum RegistrationStatus {
    PENDING,
    APPROVED,
    REJECTED;
}

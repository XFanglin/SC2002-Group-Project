package Assignment1;

public abstract class User {
    protected String nric;
    protected String name;  
    protected String password;
    protected int age;
    protected boolean married;

    public User(String nric, String name, String password, int age, boolean married) {
        this.nric    = nric;
        this.name    = name;
        this.password= password;
        this.age     = age;
        this.married = married;
    }

    public String getNric()        { return nric; }
    public String getName()        { return name; }      
    public String getPassword()    { return password; }
    public int    getAge()         { return age; }
    public boolean isMarried()     { return married; }
}

package Assignment1;

import java.util.List;
import java.util.Optional;

public interface ApplicationService {
    void apply(Application a);
    void withdraw(int applicationId);
    Optional<Application> findByApplicant(String applicantNric);
    void updateStatus(String applicantNric, String projName, Status s);
    void withdrawByName(String applicantNric, String projName);
    Report generateReport(Filter f);

    /**  
     * @return true if the given NRIC has already applied to that project  
     */
    boolean hasApplication(String applicantNric, String projName);

    /**
     * @return every Application for this NRIC (may be empty)
     */
    List<Application> getApplicationsByApplicant(String applicantNric);
    List<Application> getWithdrawalRequestsByProject(String projName);
    
    List<Application> getApplicationsByProjectAndStatus(String projectName, Status status);
    List<Application> findAllApplications();

    

}

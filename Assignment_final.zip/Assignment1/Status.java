package Assignment1;


public enum Status {
    PENDING,
    SUCCESSFUL,
    UNSUCCESSFUL,
    BOOKED
}
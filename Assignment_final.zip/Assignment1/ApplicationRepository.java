// src/Assignment1/ApplicationRepository.java
package Assignment1;

import java.io.IOException;
import java.util.List;

public interface ApplicationRepository {
    List<Application> load() throws IOException;
    void add(Application app) throws IOException;
    void update(Application app) throws IOException;
    void delete(int appId) throws IOException;
}

package Assignment1;

import java.io.IOException;
import java.util.List;
import java.io.UncheckedIOException;

public class ProjectServiceImpl implements ProjectService {
    private final ProjectRepository repo;
    private final List<Project>     cache;

    public ProjectServiceImpl(ProjectRepository repo) {
        this.repo = repo;
        try {
            cache = repo.load();
        } catch (IOException e) {
            throw new RuntimeException("Failed to load projects: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Project> getAllProjects() {
        try {
            // 1) Always reload fresh from disk
            List<Project> fresh = repo.load();
            // (optional) keep your cache in sync
            cache.clear();
            cache.addAll(fresh);
            return fresh;
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to reload projects.csv", e);
        }
    }


    @Override
    public void saveProjects(List<Project> list) {
        try {
            repo.save(list);
            // keep cache in sync
            cache.clear();
            cache.addAll(list);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void addProject(Project p) {
        try {
            repo.addProject(p);
            cache.add(p);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void updateProject(String oldName, Project updated) {
        try {
            repo.updateProject(oldName, updated);
            // update cache entry
            for (int i = 0; i < cache.size(); i++) {
                if (cache.get(i).getName().equals(oldName)) {
                    cache.set(i, updated);
                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteProject(String name) {
        try {
            repo.delete(name);
            cache.removeIf(p -> p.getName().equals(name));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
package Assignment1;

public enum AuthenticationResult {
	SUCCESS,
	INVALID_NRIC,
	WRONG_PASSWORD

}

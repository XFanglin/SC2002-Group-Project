package Assignment1;

import java.util.List;

public interface ApplicantActions {
    void viewProjects(List<Project> projects);
    void apply(Project p);
    void viewStatus();
    void withdraw();
    void submitEnquiry(String msg);
    void editEnquiry(int id, String msg);
    void deleteEnquiry(int id);
    void viewMyEnquiries();
    Project viewAppliedProject();
    
    Status getApplicationStatus();
}
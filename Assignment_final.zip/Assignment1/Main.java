package Assignment1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.List;
import Assignment1.Registration;


public class Main {
    public static void main(String[] args) {
        // Show where we're writing CSVs
        String wd = System.getProperty("user.dir");
        System.out.println("Working directory: " + wd);

        // Base path under src/Assignment1
        String base = "src/Assignment1/";

        // 1) Project repo
        FileProjectRepo projRepo;
        try {
            projRepo = new FileProjectRepo(base + "projects.csv");
            Path projPath = Paths.get(base + "projects.csv").toAbsolutePath();
            System.out.println(" → projects.csv at " + projPath +
                    " exists? " + Files.exists(projPath));
        } catch (IOException e) {
            System.err.println("ERROR initializing projects.csv: " + e.getMessage());
            return;
        }

        // 2) Service layer setup
        ProjectService ps = new ProjectServiceImpl(projRepo);

        // 2a) File-backed applications repo
        ApplicationRepository appRepo;
        try {
            appRepo = new FileApplicationRepo(base + "applications.csv", ps);
            Path appPath = Paths.get(base + "applications.csv").toAbsolutePath();
            System.out.println(" → applications.csv at " + appPath +
                    " exists? " + Files.exists(appPath));
        } catch (IOException e) {
            System.err.println("ERROR initializing applications.csv: " + e.getMessage());
            return;
        }
        ApplicationService asvc = new ApplicationServiceImpl(appRepo);

        // 2b) In-memory enquiry service
        EnquiryService esvc = new EnquiryServiceImpl();

        // 2c) File-backed registration repo + service
        FileRegistrationRepo regRepo;
        try {
            regRepo = new FileRegistrationRepo(base + "registrations.csv", ps);
            Path regPath = Paths.get(base + "registrations.csv").toAbsolutePath();
            System.out.println(" → registrations.csv at " + regPath +
                    " exists? " + Files.exists(regPath));
        } catch (IOException e) {
            System.err.println("ERROR initializing registrations.csv: " + e.getMessage());
            return;
        }

        // Create RegistrationService using the repository
        RegistrationService rsvc = new RegistrationServiceImpl(regRepo, asvc, ps);

        
     // **Hydrate**: load all registrations and attach them to their Project
        try {
            List<Registration> allRegs = regRepo.load();
            for (Registration r : allRegs) {
                ps.getAllProjects().stream()
                  .filter(p -> p.getName().equals(r.getProjectName()))
                  .findFirst()
                  .ifPresent(p -> p.getRegistrations().add(r));
            }
        } catch (IOException e) {
            System.err.println("ERROR hydrating registrations: " + e.getMessage());
            return;
        }
        
     // after you construct ApplicationService asvc...
     // 4) Hydrate applications into projects
     try {
         List<Application> allApps = ((FileApplicationRepo)appRepo).load();
         for (Application a : allApps) {
             ps.getAllProjects().stream()
               .filter(p -> p.getName().equals(a.getProject().getName()))
               .findFirst()
               .ifPresent(p -> p.getApplications().add(a));
         }
     } catch (IOException e) {
         System.err.println("ERROR hydrating applications: " + e.getMessage());
         return;
     }


        
        // 3) User repo (needs all four services)
        FileUserRepo userRepo;
        try {
            userRepo = new FileUserRepo(
                    base + "applicants.csv",
                    base + "officers.csv",
                    base + "managers.csv",
                    projRepo,
                    asvc,
                    esvc,
                    rsvc
            );
            Path p1 = Paths.get(base + "applicants.csv").toAbsolutePath();
            Path p2 = Paths.get(base + "officers.csv").toAbsolutePath();
            Path p3 = Paths.get(base + "managers.csv").toAbsolutePath();
            System.out.println(" → applicants.csv at " + p1 + " exists? " + Files.exists(p1));
            System.out.println(" → officers.csv at " + p2 + " exists? " + Files.exists(p2));
            System.out.println(" → managers.csv at " + p3 + " exists? " + Files.exists(p3));
        } catch (IOException e) {
            System.err.println("ERROR initializing user CSVs: " + e.getMessage());
            return;
        }

        // 4) Auth & CLI
        AuthService auth = new AuthServiceImpl(userRepo);
        CLI cli = new CLI(userRepo, auth, ps, asvc, esvc, rsvc);
        cli.start();
    }
}
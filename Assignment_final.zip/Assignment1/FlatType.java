package Assignment1;

public enum FlatType {
    TWO_ROOM,
    THREE_ROOM
}

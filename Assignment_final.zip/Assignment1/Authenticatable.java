package Assignment1;

public interface Authenticatable {
    boolean login(String pw);
    void    changePassword(String pw);
}

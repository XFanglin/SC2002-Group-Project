package Assignment1;

import java.util.List;
import java.util.Optional;

import Assignment1.FlatType;
import Assignment1.Application;



public class Applicant extends User implements Authenticatable, ApplicantActions {
    private Application application;
    protected final EnquiryService   enqSvc;
    protected final ApplicationService appSvc;
    

    public Applicant(String nric, String name, String password, int age, boolean married,
                     EnquiryService enqSvc, ApplicationService appSvc) {
        super(nric, name, password, age, married);
        this.enqSvc = enqSvc;
        this.appSvc = appSvc;
    }

    @Override
    public boolean login(String pw) {
        return password.equals(pw);
    }

    @Override
    public void changePassword(String pw) {
        this.password = pw;
    }
    
    

    @Override
    public void viewProjects(List<Project> projects) {
        projects.stream()
            .filter(Project::isVisible)
            .filter(p -> {
                if (!isMarried() && getAge() >= 35)
                    return p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM, 0) > 0;
                if (isMarried() && getAge() >= 21)
                    return true;
                return false;
            })
            .forEach(System.out::println);
    }

    @Override
    public void apply(Project p) {
        if (application != null)
            throw new IllegalStateException("Already applied to " + application.getProject().getName());
        if (!p.isVisible())
            throw new IllegalArgumentException("Project not open");
        if (!isMarried() && getAge() < 35)
            throw new IllegalArgumentException("Single must be ≥35");
        if (isMarried() && getAge() < 21)
            throw new IllegalArgumentException("Married must be ≥21");
        if (!isMarried() && p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM, 0) == 0)
            throw new IllegalArgumentException("No 2‑room units left");

        this.application = new Application(nric, p);
        appSvc.apply(application);
        System.out.println("Applied to " + p.getName());
    }

    @Override
    public void viewStatus() {
        // same reload logic, but print status
        Optional<Application> opt = appSvc
            .findByApplicant(getNric());
        if (opt.isEmpty()) {
            throw new IllegalStateException("No application yet");
        }
        application = opt.get();
        System.out.println("Status: " + application.getStatus());
    }

    @Override
    public void withdraw() {
        if (application == null)
            throw new IllegalStateException("No application to withdraw");
        appSvc.withdraw(application.getId());
        System.out.println("Application withdrawn");
    }

    @Override
    public void submitEnquiry(String msg) {
        Enquiry e = new Enquiry(nric, msg);
        enqSvc.submit(e);
        System.out.println("Enquiry ID: " + e.getId());
    }

    @Override
    public void editEnquiry(int id, String msg) {
        enqSvc.edit(id, msg);
        System.out.println("Edited enquiry " + id);
    }

    @Override
    public void deleteEnquiry(int id) {
        enqSvc.delete(id);
        System.out.println("Deleted enquiry " + id);
    }
    
    @Override
    public Project viewAppliedProject() {
        Optional<Application> opt = appSvc.findByApplicant(getNric());
        if (opt.isEmpty()) {
            application = null;    // drop any old cache
            return null;
        }
        application = opt.get();
        return application.getProject();
    }

    
    @Override
    public Status getApplicationStatus() {
        if (application == null) {
            return null;
        }
        return application.getStatus();
    }
        @Override
        public void viewMyEnquiries() {
            List<Enquiry> myEnquiries = enqSvc.getEnquiriesForUser(getNric());

            if (myEnquiries.isEmpty()) {
                System.out.println("You have no enquiries yet.");
            } else {
                System.out.println("Your enquiries:");
                for (Enquiry e : myEnquiries) {
                    System.out.println(e);
                }
            }
        
        

    }
    
 // In Applicant.java
    public void apply(Project p, FlatType ft) throws Exception {
        Application newApp = new Application(this.getNric(), p, ft);
        appSvc.apply(newApp);
    }
    
    

    
    
}

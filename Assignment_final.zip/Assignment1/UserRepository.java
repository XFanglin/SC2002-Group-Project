package Assignment1;


import java.io.IOException;
import java.util.Optional;

public interface UserRepository {
    Optional<User> find(String nric);
    void load()         throws IOException;
    void addUser(User u) throws IOException;
    void saveAll() throws IOException;

}
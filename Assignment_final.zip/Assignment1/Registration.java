package Assignment1;

import java.time.LocalDate;

public class Registration {
    private static int counter = 1;

    private final int           id;
    private final String        officerNric;
    private final String        projectName;
    private final LocalDate     open, close;
    private RegistrationStatus  status;
    
    private final Project project;

    public Registration(String officerNric, Project p) {
        this.id           = counter++;
        this.project      = p;
        this.officerNric  = officerNric;
        this.projectName  = p.getName();
        this.open         = p.getOpenDate();
        this.close        = p.getCloseDate();
        this.status       = RegistrationStatus.PENDING;
    }

    public int                 getId()           { return id; }
    public String              getOfficerNric()  { return officerNric; }
    public String              getProjectName()  { return projectName; }
    public LocalDate           getOpenDate()     { return open; }
    public LocalDate           getCloseDate()    { return close; }
    public RegistrationStatus  getStatus()       { return status; }
    public void                setStatus(RegistrationStatus status) {
        this.status = status;
    }

    public boolean overlaps(LocalDate a, LocalDate b) {
        return !(b.isBefore(open) || a.isAfter(close));
    }
 // ← NEW GETTER
    public Project getProject() {
        return project;
    }
}

package Assignment1;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.*;

public class FileProjectRepo implements ProjectRepository {
    private final Path projectsPath;
    private final List<Project> projects = new ArrayList<>();

    public FileProjectRepo(String csvFileName) throws IOException {
        // Always look in the working directory
        Path cwd = Paths.get(System.getProperty("user.dir"));
        this.projectsPath = cwd.resolve(csvFileName);

        // If it doesn’t exist yet, create it with the header
        if (!Files.exists(projectsPath)) {
            Files.createDirectories(projectsPath.getParent() == null
                ? cwd
                : projectsPath.getParent());
            Files.write(
                projectsPath,
                Collections.singletonList(
                    "name,neighborhood,twoRoom,threeRoom,open,close,maxOfficers,managerNric,visible"
                ),
                StandardOpenOption.CREATE_NEW
            );
        }

        // Load into memory (or you might want to cache it in your `projects` list)
        load();
    }



    @Override
    public List<Project> load() throws IOException {
        List<Project> projects = new ArrayList<>();
        try (Stream<String> lines = Files.lines(projectsPath).skip(1)) {
            lines.forEach(line -> {
                String[] f = line.split(",", -1);
                Project p = new Project(
                    f[0], f[1],
                    Integer.parseInt(f[2]),
                    Integer.parseInt(f[3]),
                    LocalDate.parse(f[4]),
                    LocalDate.parse(f[5]),
                    Integer.parseInt(f[6])
                );
                p.setManagerNric(f[7]);

                // ← add this:
                boolean vis = (f.length > 8)
                            ? Boolean.parseBoolean(f[8])
                            : true;  // default old rows to visible
                p.setVisible(vis);

                projects.add(p);
            });
        }
        return projects;
    }


    @Override
    public void save(List<Project> list) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("name,neighborhood,twoRoom,threeRoom,open,close,maxOfficers,managerNric,visible");
        for (Project p : list) {
            lines.add(String.join(",",
                p.getName(),
                p.getNeighborhood(),
                String.valueOf(p.getAvailableUnits().get(FlatType.TWO_ROOM)),
                String.valueOf(p.getAvailableUnits().get(FlatType.THREE_ROOM)),
                p.getOpenDate().toString(),
                p.getCloseDate().toString(),
                String.valueOf(p.getMaxOfficerSlots()),
                Optional.ofNullable(p.getManagerNric()).orElse(""),
                String.valueOf(p.isVisible()) 
            ));
        }
        Files.write(projectsPath, lines, StandardOpenOption.TRUNCATE_EXISTING);
        projects.clear();
        projects.addAll(list);
    }

    @Override
    public void addProject(Project p) throws IOException {
        String line = String.join(",",
            p.getName(),
            p.getNeighborhood(),
            String.valueOf(p.getAvailableUnits().get(FlatType.TWO_ROOM)),
            String.valueOf(p.getAvailableUnits().get(FlatType.THREE_ROOM)),
            p.getOpenDate().toString(),
            p.getCloseDate().toString(),
            String.valueOf(p.getMaxOfficerSlots()),
            Optional.ofNullable(p.getManagerNric()).orElse(""),
            String.valueOf(p.isVisible()) 
        );
        Files.write(projectsPath, Collections.singletonList(line), StandardOpenOption.APPEND);
        projects.add(p);
    }

    @Override
    public void updateProject(String oldName,Project updated) throws IOException {
        // 1) Load everything
        List<Project> all = load();

        // 2) Find the matching project by its current name and replace it
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getName().equals(updated.getName())) {
                all.set(i, updated);
                break;
            }
        }

        // 3) Persist back to CSV (your save method already writes 'visible' too)
        save(all);
    }

    @Override
    public void delete(String projectName) throws IOException {
        List<Project> all = load();
        all.removeIf(x -> x.getName().equals(projectName));
        save(all);
    }
}
// src/Assignment1/RegistrationRepository.java
package Assignment1;

import java.io.IOException;
import java.util.List;

public interface RegistrationRepository {
  List<Registration> load() throws IOException;
  void add(Registration r) throws IOException;
  void update(Registration r) throws IOException;
  void delete(String officerNric, String projectName) throws IOException;
}

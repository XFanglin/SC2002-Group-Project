package Assignment1;

import java.io.IOException;
import java.util.List;

public interface ProjectRepository {
    List<Project> load() throws IOException;
    void save(List<Project> projects) throws IOException;
    void addProject(Project p) throws IOException;
    void updateProject(String oldName, Project updated) throws IOException;

    void delete(String projectName) throws IOException;
}
// src/Assignment1/FileApplicationRepo.java
package Assignment1;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class FileApplicationRepo implements ApplicationRepository {
    private final Path path;
    private final List<Application> store = new ArrayList<>();
    private final ProjectService projectSvc;

    public FileApplicationRepo(String csvFilePath,
                               ProjectService projectSvc) throws IOException {
        this.path = Paths.get(csvFilePath);
        this.projectSvc = projectSvc;
        // create with header if missing
        if (!Files.exists(path)) {
            Files.write(path,
                List.of("id,applicantNric,projectName,status,withdrawalRequested"),
                StandardOpenOption.CREATE);
        }
        // load into memory
        load();
    }

    @Override
    public List<Application> load() throws IOException {
        store.clear();
        try (Stream<String> lines = Files.lines(path).skip(1)) {
            lines.forEach(line -> {
                String[] f = line.split(",", -1);
                int    id     = Integer.parseInt(f[0]);
                String nric   = f[1];
                String projNm = f[2];
                Status status   = Status.valueOf(f[3]);
                boolean wr      = Boolean.parseBoolean(f[4]);

                // ← LOOK UP PROJECT, BUT SKIP IF MISSING
                Optional<Project> optProj = projectSvc.getAllProjects().stream()
                    .filter(x -> x.getName().equals(projNm))
                    .findFirst();
                if (optProj.isEmpty()) {
                    System.err.println(
                      "⚠️ Skipping application for unknown project: " + projNm
                    );
                    return;   // skip this CSV row
                }
                Project project = optProj.get();

                // rebuild Application
                Application a = new Application(nric, project);
                a.setStatus(status);
                a.setWithdrawalRequested(wr);
                a.setId(id);    // ensure you have a setId(int) on Application
                store.add(a);
            });
        }
        return List.copyOf(store);
    }

    @Override
    public void add(Application a) throws IOException {
        String row = String.join(",",
            String.valueOf(a.getId()),
            a.getApplicantNric(),
            a.getProject().getName(),
            a.getStatus().name(),
            String.valueOf(a.isWithdrawalRequested())
        );
        Files.write(path, List.of(row), StandardOpenOption.APPEND);
        store.add(a);
    }

    @Override
    public void update(Application a) throws IOException {
        // rewrite entire file with modifications
        List<String> lines = new ArrayList<>();
        lines.add("id,applicantNric,projectName,status,withdrawalRequested");
        for (Application x : store) {
            if (x.getId() == a.getId()) x = a;  // replace
            lines.add(String.join(",",
                String.valueOf(x.getId()),
                x.getApplicantNric(),
                x.getProject().getName(),
                x.getStatus().name(),
                String.valueOf(x.isWithdrawalRequested())
            ));
        }
        Files.write(path, lines, StandardOpenOption.TRUNCATE_EXISTING);
    }

    @Override
    public void delete(int appId) throws IOException {
        store.removeIf(a -> a.getId() == appId);
        updateStoreFile();
    }

    private void updateStoreFile() throws IOException {
        // same as update but without replacing
        List<String> lines = new ArrayList<>();
        lines.add("id,applicantNric,projectName,status,withdrawalRequested");
        for (Application x : store) {
            lines.add(String.join(",",
                String.valueOf(x.getId()),
                x.getApplicantNric(),
                x.getProject().getName(),
                x.getStatus().name(),
                String.valueOf(x.isWithdrawalRequested())
            ));
        }
        Files.write(path, lines, StandardOpenOption.TRUNCATE_EXISTING);
    }
}

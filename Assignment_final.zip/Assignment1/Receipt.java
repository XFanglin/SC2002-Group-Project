package Assignment1;

public class Receipt {
    private final Application app;

    public Receipt(Application app) {
        this.app = app;
    }

    @Override
    public String toString() {
        return "Receipt:\n" +
               " Applicant: " + app.getApplicantNric() + "\n" +
               " Project:   " + app.getProject().getName() + "\n" +
               " Status:    " + app.getStatus();
    }
}
package Assignment1;


public interface OfficerActions {
    void register(Project p);
    void replyEnquiry(int id, String resp);
    void selectFlat(String applicantNric, FlatType type);
    Receipt generateReceipt(String applicantNric);
}

package Assignment1;

import java.util.List;

public interface ProjectService {
    List<Project> getAllProjects();
    void saveProjects(List<Project> list);
    void addProject(Project p);
    void updateProject(String oldName, Project updated);
    void deleteProject(String name);
}
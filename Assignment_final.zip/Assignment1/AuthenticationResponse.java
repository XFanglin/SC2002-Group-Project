package Assignment1;

public class AuthenticationResponse {
	private final AuthenticationResult result;
    private final User user;

    public AuthenticationResponse(AuthenticationResult result, User user) {
        this.result = result;
        this.user = user;
    }

    public AuthenticationResult getResult() {
        return result;
    }

    public User getUser() {
        return user;
    }

}

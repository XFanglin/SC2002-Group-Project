package Assignment1;

import java.util.List;


public interface RegistrationService {
    void   registerOfficer(String nric, Project p);
    boolean isOfficer(String nric, Project p);
    void   updateStatus(String nric, String projName, boolean ok);
    boolean hasPendingRegistration(String nric);

    /**
     * @return true if this NRIC is allowed to register —
     *         i.e. has no pending/approved officer registration
     *         and has not applied as an applicant
     */
    boolean canRegisterOfficer(String nric);
    List<Registration> getAllRegistrations();
}

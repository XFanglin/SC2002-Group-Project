// src/Assignment1/FileRegistrationRepo.java
package Assignment1;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.*;

public class FileRegistrationRepo implements RegistrationRepository {
    private final Path path;
    private final List<Registration> store = new ArrayList<>();
    private final ProjectService projectSvc;

    public FileRegistrationRepo(String csvFilePath,
                                ProjectService projectSvc) throws IOException {
        this.path       = Paths.get(csvFilePath);
        this.projectSvc = projectSvc;

        // create with header if missing
        if (!Files.exists(path)) {
            Files.write(path,
                List.of("officerNric,projectName,open,close,status"),
                StandardOpenOption.CREATE);
        }

        // read everything in and attach to projects
        load();
    }

    @Override
    public List<Registration> load() throws IOException {
        store.clear();

        // 1) Clear every project's registrations so we start fresh
        for (Project p : projectSvc.getAllProjects()) {
            p.getRegistrations().clear();
        }

        // 2) Read CSV and rehydrate each Registration, then attach to both
        try (Stream<String> lines = Files.lines(path).skip(1)) {
            lines.forEach(line -> {
                String[] f = line.split(",", -1);
                String nric    = f[0];
                String proj    = f[1];
                LocalDate open = LocalDate.parse(f[2]);
                LocalDate close= LocalDate.parse(f[3]);
                RegistrationStatus status = RegistrationStatus.valueOf(f[4]);

                // find matching Project instance
                Project p = projectSvc.getAllProjects().stream()
                    .filter(x -> x.getName().equals(proj))
                    .findFirst()
                    .orElseThrow(() -> 
                        new IllegalStateException("Unknown project in CSV: " + proj));

                // build the Registration, set its status
                Registration r = new Registration(nric, p);
                r.setStatus(status);

                // attach in two places
                store.add(r);
                p.getRegistrations().add(r);
            });
        }

        return List.copyOf(store);
    }

    @Override
    public void add(Registration r) throws IOException {
        store.add(r);
        // also attach to the project immediately
        r.getProject().getRegistrations().add(r);
        persist();
    }

    @Override
    public void update(Registration r) throws IOException {
        // replace in our in-memory list
        for (int i = 0; i < store.size(); i++) {
            Registration x = store.get(i);
            if (x.getOfficerNric().equals(r.getOfficerNric())
             && x.getProjectName().equals(r.getProjectName())) {
                store.set(i, r);
                break;
            }
        }
        // also update the one inside the Project
        Project p = r.getProject();
        p.getRegistrations().removeIf(rr ->
            rr.getOfficerNric().equals(r.getOfficerNric())
         && rr.getProjectName().equals(r.getProjectName())
        );
        p.getRegistrations().add(r);

        persist();
    }

    @Override
    public void delete(String officerNric, String projectName) throws IOException {
        store.removeIf(x ->
            x.getOfficerNric().equals(officerNric) &&
            x.getProjectName().equals(projectName));
        // also remove from the Project’s list
        projectSvc.getAllProjects().stream()
            .filter(p -> p.getName().equals(projectName))
            .findFirst()
            .ifPresent(p ->
                p.getRegistrations().removeIf(rr ->
                    rr.getOfficerNric().equals(officerNric)
                )
            );
        persist();
    }

    private void persist() {
        List<String> lines = new ArrayList<>();
        lines.add("officerNric,projectName,open,close,status");
        for (Registration r : store) {
            lines.add(String.join(",",
                r.getOfficerNric(),
                r.getProjectName(),
                r.getOpenDate().toString(),
                r.getCloseDate().toString(),
                r.getStatus().name()
            ));
        }
        try {
            Files.write(path, lines, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}

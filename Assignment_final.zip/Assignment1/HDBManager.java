package Assignment1;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class HDBManager extends User implements ManagerActions, Authenticatable {
    private final ProjectService      projSvc;
    private final RegistrationService regSvc;
    private final ApplicationService  appSvc;
    private final EnquiryService      enqSvc;

    public HDBManager(String nric, String name, String password, int age, boolean married,
                      ProjectService projSvc,
                      RegistrationService regSvc,
                      ApplicationService appSvc,
                      EnquiryService enqSvc) {
        super(nric,name, password, age, married);
        this.projSvc = projSvc;
        this.regSvc  = regSvc;
        this.appSvc  = appSvc;
        this.enqSvc  = enqSvc;
    }

    @Override public boolean login(String pw)         { return password.equals(pw); }
    @Override public void    changePassword(String pw){ this.password = pw; }

    @Override
    public void createProject(Project p) {
        // enforce single‑project per period
        List<Project> mine = projSvc.getAllProjects().stream()
            .filter(x -> this.nric.equals(x.getManagerNric()))
            .collect(Collectors.toList());
        for (Project ex : mine) {
            if (!(p.getCloseDate().isBefore(ex.getOpenDate())
               || p.getOpenDate().isAfter(ex.getCloseDate()))) {
                throw new IllegalStateException(
                  "Overlap with existing project: " + ex.getName());
            }
        }
        p.setManagerNric(this.nric);
        projSvc.addProject(p);
        System.out.println("Created project: " + p.getName());
    }

    @Override
    public void editProject(String oldName, Project p) {
        projSvc.updateProject(oldName, p);
        System.out.println("Edited project “" + oldName + "” → “" + p.getName() + "”");
    }

    @Override
    public void deleteProject(String name) {
        projSvc.deleteProject(name);
        System.out.println("Deleted project: " + name);
    }

    @Override
    public void toggleVisibility(String name, boolean on) {
        Project p = projSvc.getAllProjects().stream()
            .filter(x -> x.getName().equals(name))
            .findFirst()
            .orElseThrow(() -> new IllegalArgumentException("No such project"));
        p.setVisible(on);
        projSvc.updateProject(name, p);
        System.out.println("Visibility set to " + on + " for " + name);
    }

    @Override
    public void approveOfficer(String officerNric, String projName, boolean ok) {
        regSvc.updateStatus(officerNric, projName, ok);
        System.out.println((ok?"Approved":"Rejected") +
                           " officer " + officerNric);
    }

    @Override
    public void approveApplication(String appNric, String projName, boolean ok) {
        appSvc.updateStatus(appNric, projName,
                            ok? Status.SUCCESSFUL : Status.UNSUCCESSFUL);
        System.out.println((ok?"Approved":"Rejected") +
                           " application " + appNric);
    }

    @Override
    public void approveWithdrawal(String appNric, String projName, boolean ok) {
        if (ok) appSvc.withdrawByName(appNric, projName);
        System.out.println("Withdrawal " + (ok?"accepted":"rejected")
                           + ": " + appNric);
    }

    @Override
    public Report generateReport(Filter f) {
        return appSvc.generateReport(f);
    }

    @Override
    public void replyEnquiry(int id, String resp) {
        enqSvc.reply(id, resp);
        System.out.println("Manager replied to enquiry " + id);
    }

    @Override
    public void viewProjects(List<Project> projects) {
        projSvc.getAllProjects().forEach(System.out::println);
    }
}

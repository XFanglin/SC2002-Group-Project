package Assignment1;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
import Assignment1.FlatType;



public class Application {
    private static int counter = 1;

    private final int    id;
    private final String applicantNric;
    private final Project project;
    private Status       status              = Status.PENDING;
    private boolean      withdrawalRequested;
    private final FlatType flatType;
 
    



    public Application(String applicantNric, Project project) {
        this.id             = counter++;
        this.applicantNric  = applicantNric;
        this.project        = project;
        this.flatType       = null;                // ← assign once
        this.status         = Status.PENDING;
        this.withdrawalRequested = false;
    }
    
    
    public Application(String applicantNric, Project project, FlatType flatType) {
        this.id             = counter++;
        this.applicantNric  = applicantNric;
        this.project        = project;
        this.flatType       = flatType;            // ← assign once
        this.status         = Status.PENDING;
        this.withdrawalRequested = false;
    }
    
    public FlatType getFlatType() {
        return flatType;
    }



    public int     getId()                   { return id; }
    public String  getApplicantNric()        { return applicantNric; }
    public Project getProject()              { return project; }
    public Status  getStatus()               { return status; }
    public void    setStatus(Status status)  { this.status = status; }
    public boolean isWithdrawalRequested()   { return withdrawalRequested; }


    public void setId(int id) { /* assign to your private id field */ }
    public void setWithdrawalRequested(boolean wr) { this.withdrawalRequested = wr; }

    
    @Override
    public String toString() {
        return "App#" + id + " by " + applicantNric +
               " on " + project.getName() +
               " [" + status + "]";
    }
    
}

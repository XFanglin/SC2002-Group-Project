package Assignment1;

import java.util.function.Predicate;

/**
 * A simple filter for BTO projects. You can construct with an expression
 * to search project name/neighborhood, or use the no-arg Filter() to accept all.
 */
public class Filter implements Predicate<Project> {
    private final String expr;

    /**
     * No-arg constructor: a filter that accepts everything.
     */
    public Filter() {
        this.expr = null;
    }

    /**
     * Construct a text-based filter: matches if project name or neighborhood contains expr.
     */
    public Filter(String expr) {
        this.expr = expr == null || expr.isBlank() ? null : expr.trim().toLowerCase();
    }

    /**
     * Returns true if this filter matches the given project.
     */
    public boolean matches(Project p) {
        if (expr == null) return true;
        return p.getName().toLowerCase().contains(expr)
            || p.getNeighborhood().toLowerCase().contains(expr);
    }

    /**
     * Implements Predicate<Project>.test() by delegating to matches().
     */
    @Override
    public boolean test(Project p) {
        return matches(p);
    }

    @Override
    public String toString() {
        return expr == null ? "" : expr;
    }
}

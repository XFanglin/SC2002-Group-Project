package Assignment1;

import java.util.List;

public interface EnquiryService {
    void submit(Enquiry e);
    void reply(int id, String resp);
    void edit(int id, String msg);
    void delete(int id);
    
    List<Enquiry> getAll();
    List<Enquiry> getEnquiriesForUser(String senderNric);
}

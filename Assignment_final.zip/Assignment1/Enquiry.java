package Assignment1;

public class Enquiry {
    private static int counter = 1;

    // renamed to match the getter
    private final String senderNric;
    private final int    id;
    private String       message;
    private String       response;
    private final String projectName;


    public Enquiry(String senderNric, String message) {
        this(senderNric, "<no-project>", message);
    }
    
    public Enquiry(String senderNric, String projectName, String message) {
        this.id          = counter++;
        this.senderNric  = senderNric;
        this.projectName = projectName;     // ← new
        this.message     = message;
        this.response    = null;
    }

    
    

    public int    getId()           { return id; }
    public String getSenderNric()   { return senderNric; }
    public String getMessage()      { return message; }
    public void   setMessage(String msg)   { this.message = msg; }
    public String getResponse()     { return response; }
    public void   setResponse(String resp) { this.response = resp; }
    public String getProjectName() {
        return projectName;
    }


    @Override
    public String toString() {
        return "Enquiry#" + id + " from " + senderNric +
               ": \"" + message + "\"" +
               (response != null ? " → \""+response+"\"" : "");
    }
}

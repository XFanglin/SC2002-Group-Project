package Assignment1;


public class HDBOfficer extends Applicant implements OfficerActions {
    private final RegistrationService regSvc;
    private final ProjectService      projSvc;

    public HDBOfficer(String nric, String name, String password, int age, boolean married,
                      EnquiryService enqSvc, ApplicationService appSvc,
                      RegistrationService regSvc, ProjectService projSvc) {
        super(nric, name, password, age, married, enqSvc, appSvc);
        this.regSvc  = regSvc;
        this.projSvc = projSvc;
    }

    @Override
    public void register(Project p) {
        regSvc.registerOfficer(nric, p);
        System.out.println("Registration pending for " + p.getName());
    }

    @Override
    public void replyEnquiry(int id, String resp) {
        super.enqSvc.reply(id, resp);
        System.out.println("Replied to enquiry " + id);
    }

    @Override
    public void selectFlat(String applicantNric, FlatType type) {
        Application app = super.appSvc.findByApplicant(applicantNric)
            .orElseThrow(() -> new IllegalArgumentException("No such application"));
        if (app.getStatus() != Status.SUCCESSFUL)
            throw new IllegalStateException("Applicant not successful yet");
        Project p = app.getProject();
        p.decrementUnits(type);
        app.setStatus(Status.BOOKED);
        System.out.println("Booked flat: " + type);
    }

    @Override
    public Receipt generateReceipt(String applicantNric) {
        Application app = super.appSvc.findByApplicant(applicantNric)
            .orElseThrow(() -> new IllegalArgumentException("No such application"));
        return new Receipt(app);
    }
}
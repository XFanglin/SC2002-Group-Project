package Assignment1;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class FileUserRepo implements UserRepository {
    private final Path applicantsPath;
    private final Path officersPath;
    private final Path managersPath;
    private final Map<String,User> store = new HashMap<>();

    private final ProjectService projSvc;
    private final ApplicationService appSvc;
    private final EnquiryService enqSvc;
    private final RegistrationService regSvc;

    public FileUserRepo(String applicantsCsv,
                        String officersCsv,
                        String managersCsv,
                        ProjectRepository projRepo,
                        ApplicationService appSvc,
                        EnquiryService enqSvc,
                        RegistrationService regSvc) throws IOException {
        this.applicantsPath = Paths.get(applicantsCsv);
        this.officersPath   = Paths.get(officersCsv);
        this.managersPath   = Paths.get(managersCsv);

        this.projSvc = new ProjectServiceImpl(projRepo);
        this.appSvc  = appSvc;
        this.enqSvc  = enqSvc;
        this.regSvc  = regSvc;

        initFile(applicantsPath, "nric,name,password,age,married");
        initFile(officersPath,   "nric,name,password,age,married");
        initFile(managersPath,   "nric,name,password,age,married");
        load();
    }

    private void initFile(Path p, String header) throws IOException {
        if (!Files.exists(p)) {
            Files.write(p,
                        Collections.singletonList(header),
                        StandardOpenOption.CREATE);
        }
    }

    @Override
    public void load() throws IOException {
        store.clear();
        loadRole(applicantsPath, "APPLICANT");
        loadRole(officersPath,   "OFFICER");
        loadRole(managersPath,   "MANAGER");
    }

    private void loadRole(Path path, String role) throws IOException {
        try (Stream<String> lines = Files.lines(path).skip(1)) {
            lines.forEach(line -> {
                String[] f       = line.split(",");
                String  nric     = f[0];
                String  name     = f[1];
                String  pw       = f[2];
                int     age      = Integer.parseInt(f[3]);
                boolean married  = Boolean.parseBoolean(f[4]);
                User u;
                switch (role) {
                    case "MANAGER":
                        u = new HDBManager(nric, name,pw,age,married,
                                           projSvc, regSvc, appSvc, enqSvc);
                        break;
                    case "OFFICER":
                        u = new HDBOfficer(nric,name,pw,age,married,
                                           enqSvc, appSvc, regSvc, projSvc);
                        break;
                    default:
                        u = new Applicant(nric,name,pw,age,married,
                                          enqSvc, appSvc);
                }
                store.put(nric, u);
            });
        }
    }

    @Override
    public Optional<User> find(String nric) {
        return Optional.ofNullable(store.get(nric));
    }

    @Override
    public void addUser(User u) throws IOException {
        String line = String.join(",",
            u.getNric(),
            u.getName(),
            u.getPassword(),
            String.valueOf(u.getAge()),
            String.valueOf(u.isMarried())
        );
        Path target;
        if (u instanceof HDBManager)      target = managersPath;
        else if (u instanceof HDBOfficer) target = officersPath;
        else                              target = applicantsPath;

        Files.write(target,
                    Collections.singletonList(line),
                    StandardOpenOption.APPEND);
        store.put(u.getNric(), u);
    }
    
    
    public void saveAll() throws IOException {
        saveByRole(applicantsPath, Applicant.class);
        saveByRole(officersPath, HDBOfficer.class);
        saveByRole(managersPath, HDBManager.class);
    }
    
    
    private void saveByRole(Path path, Class<?> clazz) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("nric,name,password,age,married");
        for (User u : store.values()) {
            if (clazz.isInstance(u)) {
                lines.add(String.join(",", u.getNric(), u.getName(), u.getPassword(),
                    String.valueOf(u.getAge()), String.valueOf(u.isMarried())));
            }
        }
        Files.write(path, lines);
    }


    
    
}

package Assignment1;

import java.util.Optional;

public class AuthServiceImpl implements AuthService {
    private final UserRepository users;

    public AuthServiceImpl(UserRepository users) {
        this.users = users;
    }

    @Override
    public AuthenticationResponse authenticate(String nric, String pw) {
        Optional<User> optionalUser = users.find(nric);
        if (optionalUser.isEmpty()) {
            return new AuthenticationResponse(AuthenticationResult.INVALID_NRIC, null);
        }

        User user = optionalUser.get();
        if (user instanceof Authenticatable authenticatable && authenticatable.login(pw)) {
            return new AuthenticationResponse(AuthenticationResult.SUCCESS, user);
        }

        return new AuthenticationResponse(AuthenticationResult.WRONG_PASSWORD, null);
    }
}
package Assignment1;

public interface AuthService {
	AuthenticationResponse authenticate(String nric, String password);
}
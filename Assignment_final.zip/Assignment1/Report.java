package Assignment1;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.util.Collections;


public class Report {
    private final List<Application> apps;

    public Report(List<Application> apps) {
        this.apps = apps;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Report:\n");
        apps.forEach(a -> sb.append("  ").append(a).append("\n"));
        return sb.toString();
    }
}
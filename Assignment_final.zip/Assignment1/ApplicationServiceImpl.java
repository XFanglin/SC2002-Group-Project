package Assignment1;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ApplicationServiceImpl implements ApplicationService {
    private final ApplicationRepository repo;

    public ApplicationServiceImpl(ApplicationRepository repo) {
        this.repo = repo;
    }

    @Override
    public void apply(Application a) {
        try {
            repo.add(a);
        } catch (IOException e) {
            throw new RuntimeException("Failed to add application: " + e.getMessage(), e);
        }
    }

    @Override
    public void withdraw(int applicationId) {
        try {
            List<Application> all = repo.load();
            for (Application a : all) {
                if (a.getId() == applicationId) {
                    a.setStatus(Status.UNSUCCESSFUL);
                    a.setWithdrawalRequested(true);
                    repo.update(a);
                    return;
                }
            }
            throw new IllegalArgumentException("Application ID not found: " + applicationId);
        } catch (IOException e) {
            throw new RuntimeException("Failed to withdraw application: " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<Application> findByApplicant(String applicantNric) {
        try {
            return repo.load().stream()
                       .filter(a -> a.getApplicantNric().equals(applicantNric))
                       .findFirst();
        } catch (IOException e) {
            throw new RuntimeException("Failed to load applications: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean hasApplication(String applicantNric, String projName) {
        try {
            return repo.load().stream()
                .anyMatch(a ->
                    a.getApplicantNric().equals(applicantNric) &&
                    a.getProject().getName().equals(projName)
                );
        } catch (IOException e) {
            throw new RuntimeException("Failed to check application existence: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateStatus(String applicantNric, String projName, Status s) {
        try {
            List<Application> all = repo.load();
            for (Application a : all) {
                if (a.getApplicantNric().equals(applicantNric)
                 && a.getProject().getName().equals(projName)) {
                    a.setStatus(s);
                    repo.update(a);
                    return;
                }
            }
            throw new IllegalArgumentException(
                "No application found for NRIC=" + applicantNric +
                ", Project=" + projName
            );
        } catch (IOException e) {
            throw new RuntimeException("Failed to update application status: " + e.getMessage(), e);
        }
    }

    @Override
    public void withdrawByName(String applicantNric, String projName) {
        try {
            repo.load().stream()
                .filter(a ->
                    a.getApplicantNric().equals(applicantNric) &&
                    a.getProject().getName().equals(projName)
                )
                .findFirst()
                .ifPresent(a -> {
                    a.setStatus(Status.UNSUCCESSFUL);
                    a.setWithdrawalRequested(true);
                    try {
                        repo.update(a);
                    } catch (IOException ex) {
                        throw new RuntimeException("Failed to withdraw: " + ex.getMessage(), ex);
                    }
                });
        } catch (IOException e) {
            throw new RuntimeException("Failed to load applications: " + e.getMessage(), e);
        }
    }

    @Override
    public Report generateReport(Filter f) {
        try {
            return new Report(repo.load());
        } catch (IOException e) {
            throw new RuntimeException("Failed to generate report: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Application> getApplicationsByApplicant(String applicantNric) {
        try {
            return repo.load().stream()
                       .filter(a -> a.getApplicantNric().equals(applicantNric))
                       .collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException("Failed to load applications: " + e.getMessage(), e);
        }
    }
    @Override
    public List<Application> getWithdrawalRequestsByProject(String projName) {
        try {
            return repo.load().stream()
                .filter(a ->
                    a.getProject().getName().equals(projName)
                 && a.isWithdrawalRequested()
                )
                .collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException("Failed to load withdrawal requests", e);
        }
    }
    
    @Override
    public List<Application> getApplicationsByProjectAndStatus(String projName, Status s) {
        try {
            return repo.load().stream()
                       .filter(a -> a.getProject().getName().equals(projName)
                                 && a.getStatus() == s)
                       .collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException("Failed to load applications", e);
        }
    }
    
    @Override
    public List<Application> findAllApplications() {
        try {
            return repo.load();  // Load from your repository
        } catch (IOException e) {
            throw new RuntimeException("Failed to load applications: " + e.getMessage(), e);
        }
    }
}

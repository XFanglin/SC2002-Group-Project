package Assignment1;

import java.util.List;

public interface ManagerActions {
    void createProject(Project p);
    void editProject(String oldName, Project updated);
    void deleteProject(String name);
    void toggleVisibility(String name, boolean on);
    void approveOfficer(String officerNric, String projName, boolean ok);
    void approveApplication(String appNric, String projName, boolean ok);
    void approveWithdrawal(String appNric, String projName, boolean ok);
    Report generateReport(Filter f);
    void replyEnquiry(int id, String resp);
    void viewProjects(List<Project> allProjects);
}
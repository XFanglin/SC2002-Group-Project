// File: CLI.java
package Assignment1;

import java.util.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.stream.Collectors;
import java.time.format.DateTimeParseException;
import java.util.stream.Collectors; 
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.text.SimpleDateFormat;
import java.util.Date;


import java.util.Objects;




import Assignment1.HDBManager;
import Assignment1.Project;
import Assignment1.Application;
import Assignment1.Registration;
import Assignment1.Enquiry;
import Assignment1.FlatType;
import Assignment1.Status;
import Assignment1.RegistrationStatus;
import Assignment1.Filter;

public class CLI {
    private final UserRepository    userRepo;
    private final AuthService       auth;
    private final ProjectService    projectSvc;
    private final ApplicationService appSvc;
    private final EnquiryService    enquirySvc;
    private final RegistrationService regSvc;
    private final Scanner scanner   = new Scanner(System.in);
    private final DateTimeFormatter DATE_FMT  = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    

  
    public CLI(UserRepository userRepo,
               AuthService auth,
               ProjectService projectSvc,
               ApplicationService appSvc,
               EnquiryService enqSvc,
               RegistrationService regSvc) {
        this.userRepo   = userRepo;
        this.auth       = auth;
        this.projectSvc = projectSvc;
        this.appSvc     = appSvc;
        this.enquirySvc     = enqSvc;
        this.regSvc     = regSvc;
    }

    public void start() {
        while (true) {
            System.out.println("\n=== HDB BTO Management System ===");
            System.out.println("1) Login");
            System.out.println("2) Register (new account)");
            System.out.println("3) Exit");
            System.out.print("Choice: ");
            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1": handleLogin();    break;
                    case "2": handleRegister(); break;
                    case "3":
                        System.out.println("Goodbye!");
                        return;
                    default:
                        System.out.println("Please enter 1, 2, or 3.");
                }
            } catch (IOException ioe) {
                System.out.println("⚠️ I/O error: " + ioe.getMessage());
            }
        }
    }

    private void handleRegister() throws IOException {
        System.out.println("\n--- Register New Account ---");
        System.out.print("NRIC (S/T + 7 digits + letter): ");
        String nric = scanner.nextLine().trim().toUpperCase();
        if (!nric.matches("^[ST]\\d{7}[A-Z]$")) {
            System.out.println("Invalid NRIC format."); return;
        }
        if (userRepo.find(nric).isPresent()) {
            System.out.println("NRIC already registered."); return;
        }
        
        System.out.print("Full name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Role (1=Applicant, 2=Officer, 3=Manager): ");
        String roleChoice = scanner.nextLine().trim();
        System.out.print("Password: ");
        String pw = scanner.nextLine();
        System.out.print("Age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.print("Marital status (1=Single, 2=Married): ");
        boolean married = scanner.nextLine().trim().equals("2");

        User newUser;
        switch (roleChoice) {
            case "2":
                newUser = new HDBOfficer(nric, name, pw, age, married,
                             enquirySvc, appSvc, regSvc, projectSvc);
                break;
            case "3":
                newUser = new HDBManager(nric, name, pw, age, married,
                             projectSvc, regSvc, appSvc, enquirySvc);
                break;
            default:
                newUser = new Applicant(nric, name, pw, age, married,
                             enquirySvc, appSvc);
        }

        userRepo.addUser(newUser);
        System.out.println("Registration successful! You may now log in.");
    }

    private void handleLogin() throws IOException {
        System.out.print("\nNRIC: ");
        String nric = scanner.nextLine().trim().toUpperCase();
        if (!nric.matches("^[ST]\\d{7}[A-Z]$")) {
            System.out.println("Invalid NRIC format.");
            return;
        }

        System.out.print("Password: ");
        String pw = scanner.nextLine();

        // 1) Authenticate and handle errors
        AuthenticationResponse authResp = auth.authenticate(nric, pw);
        if (authResp.getResult() == AuthenticationResult.INVALID_NRIC) {
            System.out.println("No such account.");
            return;
        }
        if (authResp.getResult() == AuthenticationResult.WRONG_PASSWORD) {
            System.out.println("Incorrect password.");
            return;
        }

        // 2) Successful login
        User user = authResp.getUser();
        System.out.println("Welcome, " + user.getName() + "!");
        System.out.println("Logged in as " + nric);

        // 3) Dispatch to the correct menu
        if (user instanceof HDBManager) {
            managerMenu((HDBManager) user);
        }
        else if (user instanceof HDBOfficer) {
            // now *always* show the officer menu, even if not yet assigned a project
            officerMenu((HDBOfficer) user);
        }
        else {
            applicantMenu((Applicant) user);
        }
    }
    	// ── up to here ──

   

    private void applicantMenu(Applicant a) {
        while (true) {
            System.out.println("\n--- Applicant Menu ---");
            System.out.println("1) View available projects");
            System.out.println("2) Apply for project");
            System.out.println("3) View application status");
            System.out.println("4) Withdraw application");
            System.out.println("5) Manage enquiries");
            System.out.println("6) Change password");
            System.out.println("7) Logout");
            System.out.print("Choice: ");
            String c = scanner.nextLine().trim();

            try {
                switch (c) {
                case "1":
                    // 1) Gather visible projects
                    List<Project> all = projectSvc.getAllProjects();
                    List<Project> visible = all.stream()
                        .filter(Project::isVisible)
                        .collect(Collectors.toList());

                    if (visible.isEmpty()) {
                        System.out.println("\nNo BTO projects are currently visible.");
                    } else {
                        System.out.println("\nAvailable BTO Projects:");
                        System.out.printf("%-20s %-15s %-12s %-12s %-8s %-15s %-8s %-15s%n",
                            "Name", "Neighbourhood", "Open", "Close",
                            "2-Room", "Can Apply 2R", "3-Room", "Can Apply 3R");
                        System.out.println("-----------------------------------------------------------------------------------------------------------------");

                        for (Project p : visible) {
                            int twoLeft   = p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM, 0);
                            int threeLeft = p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);

                            // Determine per-type eligibility
                            boolean can2 = !a.isMarried()
                                             ? (a.getAge() >= 35 && twoLeft > 0)
                                             : (a.getAge() >= 21 && twoLeft > 0);
                            boolean can3 = !a.isMarried()
                                             ? false
                                             : (a.getAge() >= 21 && threeLeft > 0);

                            System.out.printf("%-20s %-15s %-12s %-12s %-8d %-15s %-8d %-15s%n",
                                p.getName(),
                                p.getNeighborhood(),
                                p.getOpenDate(),
                                p.getCloseDate(),
                           
                                twoLeft,
                                can2 ? "Yes" : "No",
                                threeLeft,
                                can3 ? "Yes" : "No"
                            );
                        }
                    }
                    break;
                case "2": {
                    // 0) Short-circuit if already applied
                    Project existing = a.viewAppliedProject();
                    if (existing != null) {
                        System.out.println("Already applied to " + existing.getName());
                        break;
                    }

                    // 1) Build the list of projects they’re eligible for
                    List<Project> all2 = projectSvc.getAllProjects().stream()
                        .filter(Project::isVisible)
                        .filter(p -> {
                            int two   = p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0);
                            int three = p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);
                            if (!a.isMarried()) {
                                return a.getAge() >= 35 && two > 0;
                            } else {
                                return a.getAge() >= 21 && (two + three > 0);
                            }
                        })
                        .collect(Collectors.toList());

                    if (all2.isEmpty()) {
                        System.out.println("You’re not eligible for any visible projects right now.");
                        break;
                    }

                    // 2) Print header
                    System.out.println("\nProjects you can apply for:");
                    System.out.printf("%-4s %-20s %-15s %-8s %-8s %-12s%n",
                        "No.", "Name", "Neighbourhood", "2-Room", "3-Room", "Eligible");
                    System.out.println("----------------------------------------------------------------");

                    // 3) Numbered listing + compute eligibility per flat type
                    for (int i = 0; i < all2.size(); i++) {
                        Project p = all2.get(i);
                        int twoAvail   = p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0);
                        int threeAvail = p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);

                        List<String> elig = new ArrayList<>();
                        if (!a.isMarried()) {
                            if (twoAvail > 0) elig.add("2R");
                        } else {
                            if (twoAvail > 0)   elig.add("2R");
                            if (threeAvail > 0) elig.add("3R");
                        }
                        System.out.printf("%-4d %-20s %-15s %-8d %-8d %-12s%n",
                            i + 1,
                            p.getName(),
                            p.getNeighborhood(),
                            twoAvail,
                            threeAvail,
                            String.join(",", elig)
                        );
                    }

                    // 4) Prompt for project choice
                    System.out.print("Enter project number to apply (or 0 to cancel): ");
                    int sel;
                    try {
                        sel = Integer.parseInt(scanner.nextLine().trim());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input.");
                        break;
                    }
                    if (sel <= 0 || sel > all2.size()) {
                        System.out.println("Cancelled.");
                        break;
                    }
                    Project choice = all2.get(sel - 1);

                    // 5) Determine flat type
                    int twoAvail   = choice.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0);
                    int threeAvail = choice.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);
                    FlatType ft;
                    if (twoAvail > 0 && threeAvail > 0 && a.isMarried() && a.getAge() >= 21) {
                        System.out.print("Choose flat type (2 for 2-Room, 3 for 3-Room): ");
                        String room = scanner.nextLine().trim();
                        if ("2".equals(room)) {
                            ft = FlatType.TWO_ROOM;
                        } else if ("3".equals(room)) {
                            ft = FlatType.THREE_ROOM;
                        } else {
                            System.out.println("Invalid selection.");
                            break;
                        }
                    } else if (twoAvail > 0 && (!a.isMarried() || threeAvail == 0)) {
                        ft = FlatType.TWO_ROOM;
                    } else if (threeAvail > 0 && a.isMarried()) {
                        ft = FlatType.THREE_ROOM;
                    } else {
                        System.out.println("No eligible flat types available.");
                        break;
                    }

                    // 6) Apply (no unit count deduction here!)
                    try {
                        a.apply(choice, ft);
                        System.out.println("Successfully applied to "
                            + choice.getName() + " (" + (ft == FlatType.TWO_ROOM ? "2-Room" : "3-Room") + ")");
                    } catch (Exception ex) {
                        System.out.println("!!" + ex.getMessage());
                    }
                    break;
                }

                case "3":
                    // 1) First check they’ve applied at all
                    Project applied = a.viewAppliedProject();
                    if (applied == null) {
                        System.out.println("You have not applied for any BTO project yet.");
                        break;
                    }

                    // 2) Grab the status
                    Status status = a.getApplicationStatus();  // assume this returns the enum value

                    // 3) Show tailored message per status
                    switch (status) {
                        case PENDING:
                            System.out.println("Status: PENDING");
                            System.out.println("   Your application for “" + applied.getName() + "” is under review.");
                            System.out.println("   What you can do: You may withdraw your application at any time.");
                            break;

                        case SUCCESSFUL:
                            System.out.println("Status: SUCCESSFUL");
                            System.out.println("   Congratulations! Your application was approved.");
                            System.out.println("   What you can do: Contact your HDB Officer to book your flat.");
                            break;

                        case UNSUCCESSFUL:
                            System.out.println("Status: UNSUCCESSFUL");
                            System.out.println("  We’re sorry. Your application was not approved.");
                            System.out.println("  What you can do: You may withdraw this application and apply for another project.");
                            break;

                        case BOOKED:
                            System.out.println("Status: BOOKED");
                            System.out.println("   You have successfully booked your flat in “" + applied.getName() + "”.");
                            System.out.println("   What you can do: Enjoy your new home! No further action is needed here.");
                            break;
                    }
                    break;
                    case "4": {
                    // 4) Withdraw application
                    	List<Application> myApps = appSvc
                    		.getApplicationsByApplicant(a.getNric()).stream()
                    		.filter(app -> app.getStatus() != Status.UNSUCCESSFUL)
                    		.collect(Collectors.toList());

                    	if (myApps.isEmpty()) {
                    		System.out.println("You have no applications to withdraw.");
                    		break;
                    }

                    	// Print numbered list
                    	System.out.printf("%-4s %-20s %-10s%n", "No.", "Project", "Status");
                    	System.out.println("--------------------------------------");
                    	for (int i = 0; i < myApps.size(); i++) {
                    		Application app = myApps.get(i);
                    		System.out.printf("%-4d %-20s %-10s%n",
                    			i + 1,
                    			app.getProject().getName(),
                    			app.getStatus());
                    }

                    // Prompt selection
                    	System.out.print("Enter application number to withdraw (0 to cancel): ");
                    	int sel;
                    	try {
                    		sel = Integer.parseInt(scanner.nextLine().trim());
                    	} catch (NumberFormatException e) {
                    		System.out.println("Invalid input.");
                    		break;
                    	}
                    	if (sel <= 0 || sel > myApps.size()) {
                    		System.out.println("Cancelled.");
                    		break;
                    }

                    // Perform withdrawal
                    	Application chosen = myApps.get(sel - 1);
                    	appSvc.withdrawByName(a.getNric(), chosen.getProject().getName());
                    	System.out.println("Withdrawal requested for “" 
                    	    + chosen.getProject().getName() + "”");

                    	break;
                }

                    case "5":
                        manageEnquiries(a);
                        break;
                    case "6":
                        System.out.print("New password: ");
                        a.changePassword(scanner.nextLine());
                        try {
                            userRepo.saveAll();
                        } catch (IOException e) {
                            System.out.println("Failed to save password change.");
                        }
                        System.out.println("Password changed. Please re-login.");
                        return;

                    case "7":
                        System.out.println("Logging out...");
                        return;
                    default:
                        System.out.println("Enter 1–7.");
                }
            } catch (Exception ex) {
                System.out.println("!!" + ex.getMessage());
            }
        }
    }

    private void manageEnquiries(Applicant a) {
        while (true) {
            System.out.println("\n--- My Enquiries ---");
            System.out.println("1) View all");
            System.out.println("2) Submit");
            System.out.println("3) Edit");
            System.out.println("4) Delete");
            System.out.println("5) Back");
            System.out.print("Choice: ");
            String e = scanner.nextLine().trim();

            try {
                switch (e) {
                case "1":
                    a.viewMyEnquiries();  // where a is the logged-in Applicant object
                    break;
                case "2":
                    // 1) Pick which visible project to ask about
                    List<Project> visible = projectSvc.getAllProjects().stream()
                        .filter(Project::isVisible)
                        .collect(Collectors.toList());
                    if (visible.isEmpty()) {
                        System.out.println("No visible projects to enquire about.");
                        break;
                    }
                    System.out.println("Projects you can ask about:");
                    for (int i = 0; i < visible.size(); i++) {
                        System.out.printf("%d) %s%n", i+1, visible.get(i).getName());
                    }
                    System.out.print("Select project (0 to cancel): ");
                    int pidx = Integer.parseInt(scanner.nextLine().trim());
                    if (pidx == 0) break;
                    String projName = visible.get(pidx - 1).getName();

                    // 2) Enter your question
                    System.out.print("Your question: ");
                    String msg = scanner.nextLine().trim();

                    // 3) Submit with the correct projectName
                    enquirySvc.submit(new Enquiry(a.getNric(), projName, msg));
                    System.out.println("Enquiry submitted.");
                    break;

                    case "3":
                        System.out.print("Enquiry ID: ");
                        int eid = Integer.parseInt(scanner.nextLine());
                        System.out.print("New message: ");
                        a.editEnquiry(eid, scanner.nextLine());
                        break;
                    case "4":
                        System.out.print("Enquiry ID: ");
                        a.deleteEnquiry(Integer.parseInt(scanner.nextLine()));
                        break;
                    case "5":
                        return;
                    default:
                        System.out.println("Enter 1–5.");
                }
            } catch (Exception ex) {
                System.out.println("!! " + ex.getMessage());
            }
        }
    }

    private void officerMenu(HDBOfficer o) {
        while (true) {
            System.out.println("\nHello " + o.getName() + ", Officer");
            System.out.println("1) Change Password");
            System.out.println("2) View Projects");
            System.out.println("3) Apply for BTO");
            System.out.println("4) Manage Enquiries");
            System.out.println("5) View BTO Applications status");
            System.out.println("6) Withdraw BTO Application");
            System.out.println("7) Register as Officer to Project");
            System.out.println("8) View Registration Status");
            System.out.println("9) Reply to Enquiry");
            System.out.println("10) Allocate Flats to Successful Applicants");
            System.out.println("11) Generate Application Receipt");
            
            System.out.println("12) Logout");
            System.out.print("Choice: ");

            String choice = scanner.nextLine().trim();
            try {
                switch (choice) {
                	case "1":
                		if (changePasswordFlow(o)) return; // logout to main menu
                		break;

                    case "2":  viewOfficerProjectsMenu(o);         break;
                    case "3":  applyForBTOFlow(o);                 break;
                    case "4":  manageOfficerEnquiriesFlow(o);      break;
                    case "5":  viewOfficerApplicationsFlow(o);     break;
                    case "6":  withdrawOfficerApplicationFlow(o);  break;
                    case "7": registerOfficerFlow(o);             break; 
                    case "8": viewRegistrationStatusFlow(o);      break;
                    case "9": replyEnquiryFlow(o);                break;
                    case "10": changeAppStatusFlow(o);             break;
                    case "11": generateReceiptFlow(o);              break;
                    case "12":  System.out.println("Logging out…"); return;
                    default:   System.out.println("Enter 0–16.");   break;
                }
            } catch (Exception ex) {
                System.out.println("!!" + ex.getMessage());
            }
        }
    }
    
    // for filter‐management (options 1–3):
    private final List<Filter> filters = new ArrayList<>();



    private boolean changePasswordFlow(HDBOfficer o) {
        System.out.print("New password: ");
        o.changePassword(scanner.nextLine());

        try {
            userRepo.addUser(o);    
            userRepo.saveAll();      
        } catch (IOException e) {
            System.out.println("Failed to save password change.");
        }

        System.out.println("Password changed. Please re-login.");
        return true;
    }




    
    

    
  
    // 5) Officer: View Projects sub‐menu (single shot)
  
    private void viewOfficerProjectsMenu(HDBOfficer o) {
        System.out.println("\n--- Officer: View Projects ---");
        System.out.println("1) Projects I'm handling");
        System.out.println("2) BTO projects I could apply for");
        System.out.println("0) Back");
        System.out.print("Choice: ");
        String ch = scanner.nextLine().trim();

        switch (ch) {
            case "1" -> viewHandledProjectsFlow(o);
            case "2" -> viewEligibleProjectsFlow(o);
            case "0" -> { /* just return to officerMenu */ return; }
            default  -> System.out.println("Enter 0–2.");
        }
    }

    
 // 5.1) Projects I'm handling
    private void viewHandledProjectsFlow(HDBOfficer o) {
        // 1) Load all approved registrations for this officer
        List<Registration> regs = regSvc.getAllRegistrations().stream()
            .filter(r -> r.getOfficerNric().equals(o.getNric()))
            .filter(r -> r.getStatus() == RegistrationStatus.APPROVED)
            .collect(Collectors.toList());

        // 2) If none, inform and return
        if (regs.isEmpty()) {
            System.out.println("You are not assigned to any projects.");
            return;
        }

        // 3) Map each registration to its Project object
        List<Project> mine = regs.stream()
            .map(r -> projectSvc.getAllProjects().stream()
                .filter(p -> p.getName().equals(r.getProjectName()))
                .findFirst().orElse(null))
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

        // 4) Print table header
        System.out.printf("| %-20s | %-15s | %-12s | %-12s |%n",
            "Name", "Neighbourhood", "Open Date", "Close Date");
        System.out.println("|----------------------|-----------------|--------------|--------------|");

        // 5) Print each project row
        for (Project p : mine) {
            System.out.printf("| %-20s | %-15s | %-12s | %-12s |%n",
                p.getName(),
                p.getNeighborhood(),
                p.getOpenDate(),
                p.getCloseDate()
            );
        }
    }
    

    
 // 5.2) BTO projects you could apply for (officer view)
    private void viewEligibleProjectsFlow(HDBOfficer o) {
        LocalDate today = LocalDate.now();

        // 1) Fetch all APPROVED registrations and build the handled-projects set
        final Set<String> handled = regSvc.getAllRegistrations().stream()
            .filter(r -> r.getOfficerNric().equals(o.getNric()))
            .filter(r -> r.getStatus() == RegistrationStatus.APPROVED)
            .map(Registration::getProjectName)
            .collect(Collectors.toSet());

        // 2) Filter out handled projects, only show visible/in-window ones
        List<Project> eligible = projectSvc.getAllProjects().stream()
            .filter(Project::isVisible)
            .filter(p -> !today.isBefore(p.getOpenDate()) && !today.isAfter(p.getCloseDate()))
            .filter(p -> !handled.contains(p.getName()))
            .collect(Collectors.toList());

        // 3) Empty case
        if (eligible.isEmpty()) {
            System.out.println("\nNo BTO projects available for application right now.");
            return;
        }

        // 4) Print header
        System.out.println("\nAvailable BTO Projects:");
        System.out.printf(
            "%-20s %-15s %-12s %-12s %-8s %-15s %-8s %-15s%n",
            "Name", "Neighbourhood", "Open", "Close",
            "2-Room", "Can Apply 2R", "3-Room", "Can Apply 3R"
        );
        System.out.println("-----------------------------------------------------------------------------------------------------------------");

        // 5) Print rows
        for (Project p : eligible) {
            int twoLeft   = p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0);
            int threeLeft = p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);

            boolean can2 = !o.isMarried()
                             ? (o.getAge() >= 35 && twoLeft > 0)
                             : (o.getAge() >= 21 && twoLeft > 0);
            boolean can3 = !o.isMarried()
                             ? false
                             : (o.getAge() >= 21 && threeLeft > 0);

            System.out.printf(
                "%-20s %-15s %-12s %-12s %-8d %-15s %-8d %-15s%n",
                p.getName(),
                p.getNeighborhood(),
                p.getOpenDate(),
                p.getCloseDate(),
                twoLeft,
                can2 ? "Yes" : "No",
                threeLeft,
                can3 ? "Yes" : "No"
            );
        }
    }

    
 // 6) Apply for BTO (officer-only, excluding projects they handle)
    private void applyForBTOFlow(HDBOfficer o) {
        // 0) Prevent if already applied
        Project existing = o.viewAppliedProject();
        if (existing != null) {
            System.out.println("Already applied to " + existing.getName());
            return;
        }

        LocalDate today = LocalDate.now();

        // 1) Build the list of eligible projects
        List<Project> eligible = projectSvc.getAllProjects().stream()
            .filter(Project::isVisible)                                    // visible only
            .filter(p -> !today.isBefore(p.getOpenDate()) && !today.isAfter(p.getCloseDate()))  // in-window
            .filter(p -> !regSvc.isOfficer(o.getNric(), p))               // exclude those you handle
            .filter(p -> {                                                 // age/marital & availability
                int two   = p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0);
                int three = p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);
                if (!o.isMarried()) {
                    return o.getAge() >= 35 && two > 0;
                } else {
                    return o.getAge() >= 21 && (two + three > 0);
                }
            })
            .collect(Collectors.toList());

        if (eligible.isEmpty()) {
            System.out.println("No BTO projects you can apply for right now.");
            return;
        }

        // 2) Print table (same layout as Applicant)
        System.out.println("\nProjects you can apply for:");
        System.out.printf("%-4s %-20s %-15s %-8s %-8s %-12s%n",
            "No.", "Name", "Neighbourhood", "2-Room", "3-Room", "Eligible");
        System.out.println("----------------------------------------------------------------");
        for (int i = 0; i < eligible.size(); i++) {
            Project p    = eligible.get(i);
            int twoLeft   = p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0);
            int threeLeft = p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);

            List<String> elig = new ArrayList<>();
            if (!o.isMarried()) {
                if (twoLeft > 0) elig.add("2R");
            } else {
                if (twoLeft > 0)   elig.add("2R");
                if (threeLeft > 0) elig.add("3R");
            }

            System.out.printf("%-4d %-20s %-15s %-8d %-8d %-12s%n",
                i+1, p.getName(), p.getNeighborhood(), twoLeft, threeLeft, String.join(",", elig));
        }

        // 3) Prompt selection and apply (same as before)
        System.out.print("Enter project number to apply (0 to cancel): ");
        int sel = Integer.parseInt(scanner.nextLine().trim());
        if (sel <= 0 || sel > eligible.size()) {
            System.out.println("Cancelled.");
            return;
        }
        Project choice = eligible.get(sel - 1);

        // 4) Flat-type selection
        int twoAvail   = choice.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0);
        int threeAvail = choice.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0);
        FlatType ft;
        if (o.isMarried() && twoAvail > 0 && threeAvail > 0) {
            System.out.print("Choose flat (2 for 2-Room, 3 for 3-Room): ");
            String r = scanner.nextLine().trim();
            ft = "3".equals(r) ? FlatType.THREE_ROOM : FlatType.TWO_ROOM;
        } else if (twoAvail > 0) {
            ft = FlatType.TWO_ROOM;
        } else {
            ft = FlatType.THREE_ROOM;
        }

        // 5) Perform apply
        try {
            o.apply(choice, ft);
            System.out.println("Applied to " + choice.getName()
                + " (" + (ft == FlatType.TWO_ROOM ? "2-Room" : "3-Room") + ")");
        } catch (Exception ex) {
            System.out.println("!!" + ex.getMessage());
        }
    }




    /**
     * 7) Officer: Manage Enquiries (view / submit / edit / delete)
     */
    private void manageOfficerEnquiriesFlow(HDBOfficer o) {
        while (true) {
            System.out.println("\n--- Officer: Manage Enquiries ---");
            System.out.println("1) View my enquiries");
            System.out.println("2) Submit new enquiry");
            System.out.println("3) Edit an enquiry");
            System.out.println("4) Delete an enquiry");
            System.out.println("0) Back");
            System.out.print("Choice: ");
            String ch = scanner.nextLine().trim();

            try {
                switch (ch) {
                    case "1" -> {
                        List<Enquiry> mine = enquirySvc.getAll().stream()
                            .filter(e -> e.getSenderNric().equals(o.getNric()))
                            .collect(Collectors.toList());
                        if (mine.isEmpty()) {
                            System.out.println("No enquiries submitted.");
                        } else {
                            System.out.printf("%-4s %-12s %-20s %-20s%n",
                                "ID", "Project", "Message", "Response");
                            System.out.println("----------------------------------------------------------");
                            for (Enquiry e : mine) {
                                System.out.printf("%-4d %-12s %-20s %-20s%n",
                                    e.getId(),
                                    e.getProjectName(),
                                    e.getMessage(),
                                    Optional.ofNullable(e.getResponse()).orElse("<no reply>")
                                );
                            }
                        }
                    }
                    case "2" -> {
                        System.out.print("Project name: ");
                        String proj = scanner.nextLine().trim();
                        System.out.print("Your message: ");
                        String msg  = scanner.nextLine().trim();
                        enquirySvc.submit(new Enquiry(o.getNric(), proj, msg));
                        System.out.println("Enquiry submitted.");
                    }
                    case "3" -> {
                        System.out.print("Enquiry ID to edit: ");
                        int eid = Integer.parseInt(scanner.nextLine().trim());
                        System.out.print("New message: ");
                        enquirySvc.edit(eid, scanner.nextLine().trim());
                        System.out.println("Enquiry updated.");
                    }
                    case "4" -> {
                        System.out.print("Enquiry ID to delete: ");
                        enquirySvc.delete(Integer.parseInt(scanner.nextLine().trim()));
                        System.out.println("Enquiry deleted.");
                    }
                    case "0"  -> { return; }
                    default   -> System.out.println("Enter 0–4.");
                }
            } catch (Exception ex) {
                System.out.println("!!" + ex.getMessage());
            }
        }
    }


    /**
     * 8) View my BTO applications (officer acting as applicant)
     */
    private void viewOfficerApplicationsFlow(HDBOfficer o) {
        List<Application> apps = appSvc.getApplicationsByApplicant(o.getNric());
        if (apps.isEmpty()) {
            System.out.println("You have no applications.");
            return;
        }
        System.out.printf("%-4s %-20s %-10s%n", "No.", "Project", "Status");
        System.out.println("--------------------------------");
        for (int i = 0; i < apps.size(); i++) {
            Application a = apps.get(i);
            System.out.printf(
                "%-4d %-20s %-10s%n",
                i + 1,
                a.getProject().getName(),
                a.getStatus()           // e.g. PENDING, BOOKED, etc.
            );
        }
    }


    /**
     * 9) Withdraw my BTO application
     */
    private void withdrawOfficerApplicationFlow(HDBOfficer o) {
        List<Application> active = appSvc.getApplicationsByApplicant(o.getNric()).stream()
            .filter(a -> a.getStatus() != Status.UNSUCCESSFUL)
            .collect(Collectors.toList());

        if (active.isEmpty()) {
            System.out.println("You have no applications to withdraw.");
            return;
        }

        System.out.printf("%-4s %-20s %-10s%n", "No.", "Project", "Status");
        System.out.println("---------------------------------");
        for (int i = 0; i < active.size(); i++) {
            Application a = active.get(i);
            System.out.printf("%-4d %-20s %-10s%n",
                i+1,
                a.getProject().getName(),
                a.getStatus());
        }

        System.out.print("Enter No to withdraw (0 to cancel): ");
        int sel = Integer.parseInt(scanner.nextLine().trim());
        if (sel <= 0 || sel > active.size()) {
            System.out.println("Cancelled.");
            return;
        }

        Application chosen = active.get(sel - 1);
        // same call your applicants use:
        appSvc.withdrawByName(o.getNric(), chosen.getProject().getName());
        System.out.println("Withdrawal requested for “" 
            + chosen.getProject().getName() + "”");
    }


  
 // 10) Register as Officer to Project
    private void registerOfficerFlow(HDBOfficer o) {
        // if they've already registered, stop right here
        if (!regSvc.canRegisterOfficer(o.getNric())) {
            System.out.println("Already registered");
            return;
        }

        LocalDate today = LocalDate.now();
        List<Project> eligible = projectSvc.getAllProjects().stream()
            .filter(p -> !today.isBefore(p.getOpenDate()) && !today.isAfter(p.getCloseDate()))
            // exclude any they applied for as applicant
            .filter(p -> !appSvc.hasApplication(o.getNric(), p.getName()))
            .collect(Collectors.toList());

        if (eligible.isEmpty()) {
            System.out.println("No projects available for registration.");
            return;
        }

        System.out.println("Projects available for officer registration:");
        for (int i = 0; i < eligible.size(); i++) {
            Project p = eligible.get(i);
            System.out.printf("%d) %s (Open: %s - Close: %s)%n",
                i + 1, p.getName(), p.getOpenDate(), p.getCloseDate());
        }
        System.out.print("Enter project number to register (or 0 to cancel): ");
        int sel = Integer.parseInt(scanner.nextLine().trim());
        if (sel <= 0 || sel > eligible.size()) {
            System.out.println("Cancelled.");
            return;
        }

        Project choice = eligible.get(sel - 1);
        try {
            regSvc.registerOfficer(o.getNric(), choice);
            System.out.println("Registration submitted and pending approval.");
        } catch (IllegalStateException ex) {
            System.out.println("!!" + ex.getMessage());
        }
    }

    // 11) View Registration Status
    private void viewRegistrationStatusFlow(HDBOfficer o) {
        // Fetch all registrations from disk, then filter by your NRIC
        List<Registration> regs = regSvc.getAllRegistrations().stream()
            .filter(r -> r.getOfficerNric().equals(o.getNric()))
            .collect(Collectors.toList());

        if (regs.isEmpty()) {
            System.out.println("No registrations.");
        } else {
            System.out.println("\nYour officer‐registration statuses:");
            for (Registration r : regs) {
                System.out.printf("• %s [%s → %s] : %s%n",
                    r.getProjectName(),
                    r.getOpenDate(),
                    r.getCloseDate(),
                    r.getStatus());
            }
        }
    }


    // 12) Reply to Enquiry
    private void replyEnquiryFlow(HDBOfficer o) {
        // 1) projects you’re approved on
        List<String> myProjects = projectSvc.getAllProjects().stream()
            .filter(p -> regSvc.isOfficer(o.getNric(), p))
            .map(Project::getName)
            .collect(Collectors.toList());

        // 2) only unanswered enquiries for those projects
        List<Enquiry> pending = enquirySvc.getAll().stream()
            .filter(e -> myProjects.contains(e.getProjectName()))
            .filter(e -> e.getResponse() == null)
            .collect(Collectors.toList());

        if (pending.isEmpty()) {
            System.out.println("No pending enquiries for your projects.");
            return;
        }

        // 3) display them
        System.out.printf("%-4s %-12s %-15s %s%n", "ID", "Applicant", "Project", "Question");
        System.out.println("-------------------------------------------------------------");
        for (Enquiry e : pending) {
            System.out.printf("%-4d %-12s %-15s %s%n",
                e.getId(), e.getSenderNric(), e.getProjectName(), e.getMessage());
        }

        // 4) reply
        System.out.print("Enquiry ID to reply (0 to cancel): ");
        int id = Integer.parseInt(scanner.nextLine().trim());
        if (id == 0) return;
        System.out.print("Your response: ");
        String resp = scanner.nextLine().trim();

        enquirySvc.reply(id, resp);
        System.out.println("Enquiry answered.");
    }


    /**
     * 13) Officer: book flats for successful applicants on your assigned projects
     */
    private void changeAppStatusFlow(HDBOfficer o) {
        // 1) fetch only the projects you’re approved on
        List<Project> mine = projectSvc.getAllProjects().stream()
            .filter(p -> regSvc.isOfficer(o.getNric(), p))
            .collect(Collectors.toList());
        if (mine.isEmpty()) {
            System.out.println("You have no assigned projects.");
            return;
        }

        // 2) choose a project
        System.out.println("Your projects:");
        for (int i = 0; i < mine.size(); i++) {
            Project p = mine.get(i);
            System.out.printf("%d) %s [2R:%d, 3R:%d]%n",
                i+1,
                p.getName(),
                p.getAvailableUnits().get(FlatType.TWO_ROOM),
                p.getAvailableUnits().get(FlatType.THREE_ROOM)
            );
        }
        System.out.print("Select project: ");
        int projIdx = Integer.parseInt(scanner.nextLine().trim()) - 1;
        Project proj = mine.get(projIdx);

        // 3) pull all SUCCESSFUL applications for that project
        List<Application> succ = appSvc.getApplicationsByProjectAndStatus(
            proj.getName(), Status.SUCCESSFUL);
        if (succ.isEmpty()) {
            System.out.println("No successful applications to book.");
            return;
        }

        // 4) list them with their chosen flat
        System.out.println("Successful applicants:");
        for (int i = 0; i < succ.size(); i++) {
            Application a = succ.get(i);
            String flatLabel = (a.getFlatType() == FlatType.TWO_ROOM ? "2-Room" : "3-Room");
            System.out.printf("%d) %s (Flat: %s)%n",
                i+1, a.getApplicantNric(), flatLabel);
        }
        System.out.print("Choose applicant (0 to cancel): ");
        int choice = Integer.parseInt(scanner.nextLine().trim());
        if (choice == 0) return;
        Application a = succ.get(choice - 1);

        // 5) choose flat type
        System.out.print("Choose flat type (2 or 3): ");
        int ftChoice = Integer.parseInt(scanner.nextLine().trim());
        FlatType ft = (ftChoice == 2
            ? FlatType.TWO_ROOM
            : ftChoice == 3
                ? FlatType.THREE_ROOM
                : null);
        if (ft == null) {
            System.out.println("Invalid flat type.");
            return;
        }

        // 6) decrement inventory, persist project, then update application status
        try {
            proj.decrementUnits(ft);
            projectSvc.updateProject(proj.getName(), proj);

            System.out.println("\n— Updated Application —");
            System.out.printf("%-4s %-12s %-8s %-10s%n", "ID", "Applicant", "Flat", "Status");
            System.out.println("-------------------------------------");
            String flatLabel = (a.getFlatType() == FlatType.TWO_ROOM ? "2-Room" : "3-Room");
            System.out.printf("%-4d %-12s %-8s %-10s%n",
                a.getId(),
                a.getApplicantNric(),
                flatLabel,
                a.getStatus()
            );
        } catch (IllegalArgumentException e) {
            System.out.println("No more " + ftChoice + "-Room flats left.");
            return;
        }

        // 7) immediately show the refreshed applications list
        System.out.println("\nYour updated applications:");
        appSvc.updateStatus(a.getApplicantNric(), proj.getName(), Status.BOOKED);

    }
    //14 generate receipt
    private void generateReceiptFlow(HDBOfficer officer) {
        // a) pick one of your assigned projects
        List<Project> mine = projectSvc.getAllProjects().stream()
            .filter(p -> regSvc.isOfficer(officer.getNric(), p))
            .collect(Collectors.toList());
        if (mine.isEmpty()) {
            System.out.println("You have no assigned projects.");
            return;
        }
        System.out.println("Your projects:");
        for (int i = 0; i < mine.size(); i++) {
            System.out.printf("%d) %s%n", i + 1, mine.get(i).getName());
        }
        System.out.print("Select project: ");
        int projIdx = Integer.parseInt(scanner.nextLine().trim()) - 1;
        Project proj = mine.get(projIdx);

        // b) list all BOOKED applications for that project
        List<Application> booked = appSvc.getApplicationsByProjectAndStatus(
            proj.getName(), Status.BOOKED);
        if (booked.isEmpty()) {
            System.out.println("No booked applications for this project.");
            return;
        }
        System.out.println("Booked applicants:");
        for (int i = 0; i < booked.size(); i++) {
            Application a = booked.get(i);
            System.out.printf("%d) %s%n", i + 1, a.getApplicantNric());
        }
        System.out.print("Select applicant: ");
        int appIdx = Integer.parseInt(scanner.nextLine().trim()) - 1;
        Application app = booked.get(appIdx);

        // c) fetch full applicant details
        User user = userRepo.find(app.getApplicantNric())
            .orElseThrow(() -> new IllegalStateException("Applicant not found"));

        // d) build the receipt
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String now = fmt.format(new Date());

        StringBuilder receipt = new StringBuilder();
        receipt.append("=== BTO APPLICATION RECEIPT ===\n");
        receipt.append("Date: ").append(now).append("\n\n");

        receipt.append("APPLICANT DETAILS:\n");
        receipt.append("Name: ").append(user.getName()).append("\n");
        receipt.append("NRIC: ").append(user.getNric()).append("\n");
        receipt.append("Age: ").append(user.getAge()).append("\n");
        receipt.append("Marital Status: ")
               .append(user.isMarried() ? "Married" : "Single").append("\n\n");

        receipt.append("APPLICATION DETAILS:\n");
        receipt.append("Project Name: ").append(proj.getName()).append("\n");
        receipt.append("Neighbourhood: ").append(proj.getNeighborhood()).append("\n");
        receipt.append("Open Date: ").append(proj.getOpenDate()).append("\n");
        receipt.append("Close Date: ").append(proj.getCloseDate()).append("\n");
        receipt.append("Flat Type: ").append(app.getFlatType()).append("\n");
        receipt.append("Officer In Charge: ").append(proj.getManagerNric()).append("\n");
        receipt.append("Status: ").append(app.getStatus()).append("\n\n");

        receipt.append("=== THANK YOU FOR YOUR APPLICATION ===\n");

        // e) print it
        System.out.println(receipt.toString());
    }


        // Call this after you've authenticated an HDBManager "m"
    private void managerMenu(HDBManager m) {
        while (true) {
            System.out.println("\n--- HDB Manager Menu ---");
            System.out.println(" 1) View all projects");
            System.out.println(" 2) Create a new project");
            System.out.println(" 3) Edit project");
            System.out.println(" 4) Delete project");
            System.out.println(" 5) Toggle visibility");
            System.out.println(" 6) View my projects");
            System.out.println(" 7) View officer registrations");
            System.out.println(" 8) Process officer registration");
            System.out.println(" 9) Approve applicant application");
            System.out.println("10) Reject applicant application");
            System.out.println("11) Approve withdrawal request");
            System.out.println("12) Reject withdrawal request");
            System.out.println("13) View all enquiries");            
            System.out.println("14) View & reply to my project enquiries");        
            System.out.println("15) Generate report");                   
            System.out.println("16) Change password");
            System.out.println("17) Logout");
            System.out.print("Choice: ");
            String ch = scanner.nextLine().trim();

            try {
                switch (ch) {
                    case "1"  -> viewAllProjectsFlow();
                    case "2"  -> createProjectFlow(m);
                    case "3"  -> editProjectFlow(m);
                    case "4"  -> deleteProjectFlow(m);
                    case "5"  -> toggleVisibilityFlow(m);
                    case "6"  -> viewMyProjectsFlow(m);
                    case "7"  -> viewOfficerRegsFlow(m);
                    case "8"  -> processOfficerRegFlow(m);
                    case "9"  -> processApplicantAppFlow(m, true);
                    case "10" -> processApplicantAppFlow(m, false);
                    case "11" -> processWithdrawalFlow(m, true);
                    case "12" -> processWithdrawalFlow(m, false);
                    case "13" -> viewAllEnquiriesFlow(m);      
                    case "14" -> replyProjectEnquiriesFlow(m);
                    case "15" -> generateReportFlow(m);
                    case "16" -> {
                        if (changePasswordFlow(m)) return;
                    }

                    case "17" -> { System.out.println("Logging out..."); return; }
                    default   -> System.out.println("Please enter 1–17.");
                }
            } catch (Exception ex) {
                System.out.println("!!" + ex.getMessage());
            }
        }
    }

        // 1) View all projects
 // 1) View all projects (manager sees every project with full details)
    private void viewAllProjectsFlow() {
        List<Project> all = projectSvc.getAllProjects();
        if (all.isEmpty()) {
            System.out.println("No projects found.");
            return;
        }

        // Table header
        System.out.printf(
            "| %-20s | %-15s | %10s | %10s | %-12s | %5s | %-12s | %-12s |%n",
            "Name", "Neighbourhood", "2-Room#", "3-Room#", "Manager", "Slots", "Open Date", "Close Date"
        );
        System.out.println(
            "|----------------------|-----------------|------------|------------|--------------|-------|--------------|--------------|"
        );

        // Table rows
        for (Project p : all) {
            System.out.printf(
                "| %-20s | %-15s | %10d | %10d | %-12s | %5d | %-12s | %-12s |%n",
                p.getName(),
                p.getNeighborhood(),
                p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0),
                p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0),
                p.getManagerNric(),
                p.getMaxOfficerSlots(),
                p.getOpenDate(),
                p.getCloseDate()
            );
        }
    }


        // 2) Create a new project
        private void createProjectFlow(HDBManager m) {
            System.out.println("\n--- Create New BTO Project ---");
            System.out.print("Enter project name: ");
            String name = scanner.nextLine().trim();
            System.out.print("Enter neighbourhood: ");
            String nb = scanner.nextLine().trim();

            LocalDate open;
            while (true) {
                System.out.print("Opening date (YYYY-MM-DD): ");
                try {
                    open = LocalDate.parse(scanner.nextLine().trim(), DATE_FMT);
                    break;
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format.");
                }
            }

            LocalDate close;
            while (true) {
                System.out.print("Closing date (YYYY-MM-DD): ");
                try {
                    close = LocalDate.parse(scanner.nextLine().trim(), DATE_FMT);
                    if (!close.isAfter(open)) {
                        System.out.println("Closing must be after opening.");
                    } else {
                        break;
                    }
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format.");
                }
            }

            int twoRoom, threeRoom, slots;
            try {
                System.out.print("2-Room units: ");
                twoRoom = Integer.parseInt(scanner.nextLine().trim());
                System.out.print("3-Room units: ");
                threeRoom = Integer.parseInt(scanner.nextLine().trim());
                System.out.print("Max officer slots (0–10): ");
                slots = Integer.parseInt(scanner.nextLine().trim());
                if (twoRoom < 0 || threeRoom < 0 || slots < 0 || slots > 10) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid numeric input.");
                return;
            }

            Project p = new Project(name, nb, twoRoom, threeRoom, open, close, slots);
            m.createProject(p);
        }

        // 3) Edit project
        private void editProjectFlow(HDBManager m) {
            List<Project> mine = projectSvc.getAllProjects().stream()
                .filter(pj -> m.getNric().equals(pj.getManagerNric()))
                .toList();
            if (mine.isEmpty()) {
                System.out.println("No projects to edit.");
                return;
            }

            System.out.println("Select project to edit:");
            for (int i = 0; i < mine.size(); i++) {
                System.out.printf("  %d) %s%n", i+1, mine.get(i).getName());
            }
            System.out.print("Choice: ");
            int idx = Integer.parseInt(scanner.nextLine().trim()) - 1;
            if (idx < 0 || idx >= mine.size()) {
                System.out.println("Invalid selection.");
                return;
            }

            Project toEdit = mine.get(idx);
            String origName = toEdit.getName();
            Map<String,String[]> changes = new LinkedHashMap<>();
            boolean editing = true;

            while (editing) {
                System.out.println("\nEdit:");
                System.out.printf("1) Name        (%s)%n", toEdit.getName());
                System.out.printf("2) Neighbourhood (%s)%n", toEdit.getNeighborhood());
                System.out.printf("3) 2-Room      (%d)%n", toEdit.getAvailableUnits().get(FlatType.TWO_ROOM));
                System.out.printf("4) 3-Room      (%d)%n", toEdit.getAvailableUnits().get(FlatType.THREE_ROOM));
                System.out.printf("5) Open        (%s)%n", toEdit.getOpenDate());
                System.out.printf("6) Close       (%s)%n", toEdit.getCloseDate());
                System.out.printf("7) Slots       (%d)%n", toEdit.getMaxOfficerSlots());
                System.out.println("8) Done");
                System.out.print("Choice: ");

                switch (scanner.nextLine().trim()) {
                    case "1" -> {
                        String old = toEdit.getName();
                        System.out.print("New name: ");
                        String v = scanner.nextLine().trim();
                        if (!v.isEmpty() && !v.equals(old)) {
                            toEdit.setName(v);
                            changes.put("Name", new String[]{old, v});
                        } else {
                            System.out.println("No change.");
                        }
                    }
                    case "2" -> {
                        String old = toEdit.getNeighborhood();
                        System.out.print("New neighbourhood: ");
                        String v = scanner.nextLine().trim();
                        if (!v.isEmpty() && !v.equals(old)) {
                            toEdit.setNeighborhood(v);
                            changes.put("Neighbourhood", new String[]{old, v});
                        } else {
                            System.out.println("No change.");
                        }
                    }
                    case "3" -> {
                        int old = toEdit.getAvailableUnits().get(FlatType.TWO_ROOM);
                        System.out.print("New 2-Room #: ");
                        try {
                            int v = Integer.parseInt(scanner.nextLine().trim());
                            if (v != old) {
                                toEdit.getAvailableUnits().put(FlatType.TWO_ROOM, v);
                                changes.put("2-Room", new String[]{String.valueOf(old),String.valueOf(v)});
                            } else {
                                System.out.println("No change.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid.");
                        }
                    }
                    case "4" -> {
                        int old = toEdit.getAvailableUnits().get(FlatType.THREE_ROOM);
                        System.out.print("New 3-Room #: ");
                        try {
                            int v = Integer.parseInt(scanner.nextLine().trim());
                            if (v != old) {
                                toEdit.getAvailableUnits().put(FlatType.THREE_ROOM, v);
                                changes.put("3-Room", new String[]{String.valueOf(old),String.valueOf(v)});
                            } else {
                                System.out.println("No change.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid.");
                        }
                    }
                    case "5" -> {
                        System.out.print("New open date: ");
                        String in = scanner.nextLine().trim();
                        try {
                            LocalDate v = LocalDate.parse(in, DATE_FMT);
                            if (!v.equals(toEdit.getOpenDate())) {
                                changes.put("Open", new String[]{toEdit.getOpenDate().toString(), v.toString()});
                                toEdit.setOpenDate(v);
                            } else {
                                System.out.println("No change.");
                            }
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid date.");
                        }
                    }
                    case "6" -> {
                        System.out.print("New close date: ");
                        String in = scanner.nextLine().trim();
                        try {
                            LocalDate v = LocalDate.parse(in, DATE_FMT);
                            if (v.isAfter(toEdit.getOpenDate()) && !v.equals(toEdit.getCloseDate())) {
                                changes.put("Close", new String[]{toEdit.getCloseDate().toString(), v.toString()});
                                toEdit.setCloseDate(v);
                            } else {
                                System.out.println("Invalid or no change.");
                            }
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid date.");
                        }
                    }
                    case "7" -> {
                        int old = toEdit.getMaxOfficerSlots();
                        System.out.print("New slots: ");
                        try {
                            int v = Integer.parseInt(scanner.nextLine().trim());
                            if (v>=0 && v<=10 && v!=old) {
                                changes.put("Slots", new String[]{String.valueOf(old),String.valueOf(v)});
                                toEdit.setMaxOfficerSlots(v);
                            } else {
                                System.out.println("Invalid or no change.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid.");
                        }
                    }
                    case "8" -> editing = false;
                    default  -> System.out.println("Enter 1–8 only.");
                }
            }

            m.editProject(origName, toEdit);
            if (changes.isEmpty()) {
                System.out.println("No edits made.");
            } else {
                System.out.println("Updated:");
                changes.forEach((k, v) ->
                    System.out.printf(" • %s: %s → %s%n", k, v[0], v[1]));
            }
        }

        // 4) Delete project
        private void deleteProjectFlow(HDBManager m) {
            List<Project> mine = projectSvc.getAllProjects().stream()
                .filter(pj -> m.getNric().equals(pj.getManagerNric()))
                .toList();
            if (mine.isEmpty()) {
                System.out.println("No projects to delete.");
                return;
            }

            System.out.println("Select project to delete:");
            for (int i = 0; i < mine.size(); i++) {
                System.out.printf("  %d) %s%n", i+1, mine.get(i).getName());
            }
            System.out.print("Choice: ");
            int idx = Integer.parseInt(scanner.nextLine().trim()) - 1;
            if (idx < 0 || idx >= mine.size()) {
                System.out.println("Invalid.");
                return;
            }

            Project toDel = mine.get(idx);
            System.out.print("Confirm delete \"" + toDel.getName() + "\"? (Y/N): ");
            if (scanner.nextLine().trim().equalsIgnoreCase("Y")) {
                m.deleteProject(toDel.getName());
                System.out.println("Deleted.");
            } else {
                System.out.println("Cancelled.");
            }
        }

        // 5) Toggle visibility
        private void toggleVisibilityFlow(HDBManager m) {
            Project p = chooseMyProject(m);
            System.out.printf("Currently %s. Show? (true/false): ",
                p.isVisible() ? "visible" : "hidden");
            boolean on = Boolean.parseBoolean(scanner.nextLine().trim());
            m.toggleVisibility(p.getName(), on);
        }

     // 6) View My Projects (manager sees only their own, in table form)
        private void viewMyProjectsFlow(HDBManager m) {
            List<Project> mine = projectSvc.getAllProjects().stream()
                .filter(p -> p.getManagerNric().equals(m.getNric()))
                .collect(Collectors.toList());

            if (mine.isEmpty()) {
                System.out.println("You have not created any projects.");
                return;
            }

            // Table header
            System.out.printf(
                "| %-20s | %-15s | %10s | %10s | %-12s | %5s | %-12s | %-12s |%n",
                "Name", "Neighbourhood", "2-Room#", "3-Room#", "Manager", "Slots", "Open Date", "Close Date"
            );
            System.out.println(
                "|----------------------|-----------------|------------|------------|--------------|-------|--------------|--------------|"
            );

            // Table rows
            for (Project p : mine) {
                System.out.printf(
                    "| %-20s | %-15s | %10d | %10d | %-12s | %5d | %-12s | %-12s |%n",
                    p.getName(),
                    p.getNeighborhood(),
                    p.getAvailableUnits().getOrDefault(FlatType.TWO_ROOM,   0),
                    p.getAvailableUnits().getOrDefault(FlatType.THREE_ROOM, 0),
                    p.getManagerNric(),
                    p.getMaxOfficerSlots(),
                    p.getOpenDate(),
                    p.getCloseDate()
                );
            }
        }


        // 7) View officer registrations
        /**
         * View officer registrations for a selected project.
         * 
         * @param m The HDB Manager viewing registrations
         */
          // 7) View officer registrations for manager
        private void viewOfficerRegsFlow(HDBManager m) {
            Project p = chooseMyProject(m);
            
            // ADD: load fresh registrations for this project
            List<Registration> regs = regSvc.getAllRegistrations().stream()
                .filter(r -> r.getProjectName().equals(p.getName()))
                .collect(Collectors.toList());

            // 2) Empty case
            if (regs.isEmpty()) {
                System.out.println("No officer registrations for \"" + p.getName() + "\".");
                return;
            }

            // 3) Print table
            System.out.printf("%-4s %-12s %-12s %-12s %-10s%n",
                "ID", "Officer", "Open", "Close", "Status");
            System.out.println("---------------------------------------------------------");
            for (Registration r : regs) {
                System.out.printf("%-4d %-12s %-12s %-12s %-10s%n",
                    r.getId(),
                    r.getOfficerNric(),
                    r.getOpenDate(),
                    r.getCloseDate(),
                    r.getStatus());
            }
        }


        //  process officer registrations for manager
     // 8) Process (approve/reject) officer registrations
        private void processOfficerRegFlow(HDBManager m) {
            Project p = chooseMyProject(m);

            // 1) Only PENDING registrations
         // 1) Only PENDING registrations (from service)
            List<Registration> pending = regSvc.getAllRegistrations().stream()
                .filter(r -> r.getProjectName().equals(p.getName()))
                .filter(r -> r.getStatus() == RegistrationStatus.PENDING)
                .collect(Collectors.toList());


            if (pending.isEmpty()) {
                System.out.println("No pending officer registrations for \"" + p.getName() + "\".");
                return;
            }

            // 2) Print table of pending
            System.out.printf("%-4s %-12s %-12s %-12s %-10s%n",
                "ID", "Officer", "Open", "Close", "Status");
            System.out.println("---------------------------------------------------------");
            for (Registration r : pending) {
                System.out.printf("%-4d %-12s %-12s %-12s %-10s%n",
                    r.getId(),
                    r.getOfficerNric(),
                    r.getOpenDate(),
                    r.getCloseDate(),
                    r.getStatus());
            }

            // 3) Prompt
            System.out.print("Enter Reg ID to process (or 0 to cancel): ");
            int rid = Integer.parseInt(scanner.nextLine().trim());
            if (rid == 0) {
                System.out.println("Cancelled.");
                return;
            }

            // 4) Find the chosen pending registration
            Registration chosen = pending.stream()
                .filter(r -> r.getId() == rid)
                .findFirst()
                .orElseThrow(() ->
                    new IllegalArgumentException("Invalid or non‐pending Reg ID: " + rid)
                );

            // 5) Ask approve or reject
            System.out.print("Approve this registration? (Y/N): ");
            boolean ok = scanner.nextLine().trim().equalsIgnoreCase("Y");

            // 6) Call manager’s service
            m.approveOfficer(chosen.getOfficerNric(), p.getName(), ok);

            System.out.println("Registration " + rid +
                (ok ? " approved." : " rejected."));
        }


        // 9 & 10) Approve/reject applicant application
     // 10) Process Applicant Applications (approve or reject)
     // process applicant applications (approve or reject)
        private void processApplicantAppFlow(HDBManager m, boolean approve) {
            Project p = chooseMyProject(m);

            List<Application> pending = 
            	    appSvc.getApplicationsByProjectAndStatus(p.getName(), Status.PENDING);


            if (pending.isEmpty()) {
                System.out.println("No pending applications for \"" + p.getName() + "\".");
                return;
            }

            // print table
            System.out.printf("%-4s %-12s %-10s%n", "ID", "Applicant", "Status");
            System.out.println("-------------------------------");
            for (Application a : pending) {
                System.out.printf("%-4d %-12s %-10s%n",
                    a.getId(),
                    a.getApplicantNric(),
                    a.getStatus());
            }

            String action = approve ? "approve" : "reject";
            System.out.print("Application ID to " + action + " (0 to cancel): ");
            int id = Integer.parseInt(scanner.nextLine().trim());
            if (id == 0) {
                System.out.println("Cancelled.");
                return;
            }

            Application picked = pending.stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid Application ID"));

            // ← use the correct ManagerActions method here:
            m.approveApplication(picked.getApplicantNric(), p.getName(), approve);

            System.out.println("Application " + id + " has been " +
                (approve ? "approved." : "rejected."));
        }

        

        /**
         * Combined Approve/Reject Withdrawal flow.
         *
         * @param m        the manager
         * @param approve  true ⇒ approve; false ⇒ reject
         */
        private void processWithdrawalFlow(HDBManager m, boolean approve) {
            Project p = chooseMyProject(m);

            // 1) Load only those apps with withdrawal requested
            List<Application> reqs = appSvc.getWithdrawalRequestsByProject(p.getName());
            if (reqs.isEmpty()) {
                System.out.println("No withdrawal requests for \"" + p.getName() + "\".");
                return;
            }

            // 2) Print table header
            System.out.printf("%-4s %-12s %-10s%n", "ID", "Applicant", "Status");
            System.out.println("----------------------------");
            for (Application a : reqs) {
                System.out.printf("%-4d %-12s %-10s%n",
                    a.getId(),
                    a.getApplicantNric(),
                    a.getStatus());
            }

            // 3) Prompt for ID
            String action = approve ? "approve" : "reject";
            System.out.print("Withdraw Request ID to " + action + " (0 to cancel): ");
            int id;
            try {
                id = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input.");
                return;
            }
            if (id == 0) {
                System.out.println("Cancelled.");
                return;
            }

            // 4) Find the chosen request
            Application chosen = reqs.stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid Request ID"));

            // 5) Call manager’s service
            m.approveWithdrawal(chosen.getApplicantNric(), p.getName(), approve);

            // 6) Confirmation
            System.out.println("Withdrawal request " + id + " has been "
                + (approve ? "approved." : "rejected."));
        }

     //12) reject withdrawal
     // 12) Process withdrawal requests
        private void processWithdrawalRequestsFlow(HDBManager m) {
            Project p = chooseMyProject(m);

            List<Application> requests = p.getApplications().stream()
                .filter(Application::isWithdrawalRequested)
                .collect(Collectors.toList());

            if (requests.isEmpty()) {
                System.out.println("No withdrawal requests to process for \"" + p.getName() + "\".");
                return;
            }

            // Same header as above
            System.out.printf("%-4s %-12s %-10s%n", "ID", "Applicant", "Status");
            System.out.println("----------------------------");
            for (Application a : requests) {
                System.out.printf("%-4d %-12s %-10s%n",
                    a.getId(),
                    a.getApplicantNric(),
                    a.getStatus());
            }

            System.out.print("Enter Application ID to process (0 to cancel): ");
            int id = Integer.parseInt(scanner.nextLine().trim());
            if (id == 0) {
                System.out.println("Cancelled.");
                return;
            }

            Application chosen = requests.stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid Application ID"));

            System.out.print("Accept withdrawal? (Y/N): ");
            boolean ok = scanner.nextLine().trim().equalsIgnoreCase("Y");

            m.approveWithdrawal(chosen.getApplicantNric(), p.getName(), ok);
            System.out.println("Withdrawal request " + id +
                (ok ? " approved." : " rejected."));
        }

     // 13) View all enquiries across every project
        private void viewAllEnquiriesFlow(HDBManager m) {
            List<Enquiry> all = enquirySvc.getAll();
            if (all.isEmpty()) {
                System.out.println("No enquiries in the system.");
                return;
            }

            System.out.printf("%-4s %-12s %-15s %-12s %s%n",
                "ID","Applicant","Project","Answered?","Question");
            System.out.println("-----------------------------------------------------------------");
            for (Enquiry e : all) {
                boolean answered = e.getResponse() != null;
                System.out.printf("%-4d %-12s %-15s %-12s %s%n",
                    e.getId(),
                    e.getSenderNric(),
                    e.getProjectName(),
                    (answered ? "Yes" : "No"),
                    e.getMessage()
                );
                if (answered) {
                    System.out.printf("      → Response: \"%s\"%n", e.getResponse());
                }
            }
        }



        // 14) View & reply to enquiries
        private void replyProjectEnquiriesFlow(HDBManager m) {
            // 1) names of projects you created
            Set<String> mine = projectSvc.getAllProjects().stream()
                .filter(p -> p.getManagerNric().equals(m.getNric()))
                .map(Project::getName)
                .collect(Collectors.toSet());

            // 2) only unanswered enquiries for those projects
            List<Enquiry> pending = enquirySvc.getAll().stream()
                .filter(e -> mine.contains(e.getProjectName()))
                .filter(e -> e.getResponse() == null)
                .collect(Collectors.toList());

            if (pending.isEmpty()) {
                System.out.println("No pending enquiries for your projects.");
                return;
            }

            // 3) display them
            System.out.printf("%-4s %-12s %-15s %s%n", "ID","Applicant","Project","Question");
            System.out.println("-------------------------------------------------------------");
            for (Enquiry e : pending) {
                System.out.printf("%-4d %-12s %-15s %s%n",
                    e.getId(), e.getSenderNric(), e.getProjectName(), e.getMessage());
            }

            // 4) reply
            System.out.print("Enquiry ID to reply (0 to cancel): ");
            int id = Integer.parseInt(scanner.nextLine().trim());
            if (id == 0) return;
            System.out.print("Your response: ");
            String resp = scanner.nextLine().trim();

            enquirySvc.reply(id, resp);
            System.out.println("Enquiry answered.");
        }


        // 15) Generate report
        private void generateReportFlow(HDBManager m) {
            List<Application> allApplications = appSvc.findAllApplications();

            if (allApplications.isEmpty()) {
                System.out.println("No applications available for reporting.");
                return;
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("\n--- Filter Options ---");
            System.out.print("Filter by status (PENDING, SUCCESSFUL, UNSUCCESSFUL, BOOKED or ALL): ");
            String statusInput = scanner.nextLine().trim().toUpperCase();
            Status statusFilter = null;
            if (!statusInput.equals("ALL")) {
                try {
                    statusFilter = Status.valueOf(statusInput);
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid status. Showing all.");
                }
            }

            System.out.print("Filter by flat type (2R, 3R, or ALL): ");
            String flatInput = scanner.nextLine().trim().toUpperCase();
            FlatType flatFilter = null;
            if (flatInput.equals("2R")) flatFilter = FlatType.TWO_ROOM;
            else if (flatInput.equals("3R")) flatFilter = FlatType.THREE_ROOM;

            System.out.print("Filter by marital status (SINGLE, MARRIED, or ALL): ");
            String maritalInput = scanner.nextLine().trim().toUpperCase();
            Boolean marriedFilter = null;
            if (maritalInput.equals("SINGLE")) marriedFilter = false;
            else if (maritalInput.equals("MARRIED")) marriedFilter = true;

            System.out.print("Filter by neighbourhood (leave empty for ALL): ");
            String neighborhoodInput = scanner.nextLine().trim();
            if (neighborhoodInput.equalsIgnoreCase("ALL")) neighborhoodInput = ""; // Treat 'ALL' as no filter

            final Status sf = statusFilter;
            final FlatType ff = flatFilter;
            final Boolean mf = marriedFilter;
            final String nh = neighborhoodInput.toLowerCase();

            List<Application> filtered = allApplications.stream()
                .filter(a -> sf == null || a.getStatus() == sf)
                .filter(a -> ff == null || (a.getFlatType() != null && a.getFlatType() == ff))
                .filter(a -> {
                    if (mf == null) return true;
                    Optional<User> user = userRepo.find(a.getApplicantNric());
                    if (user.isPresent() && user.get() instanceof Applicant) {
                        return ((Applicant) user.get()).isMarried() == mf;
                    }
                    return true;
                })
                .filter(a -> nh.isEmpty() || a.getProject().getNeighborhood().equalsIgnoreCase(nh))
                .collect(Collectors.toList());

            if (filtered.isEmpty()) {
                System.out.println("No matching applications found.");
                return;
            }

            System.out.println("\n--- Filtered Report ---");
            for (Application a : filtered) {
                String flat = a.getFlatType() != null ? a.getFlatType().toString() : "-";
                Optional<User> user = userRepo.find(a.getApplicantNric());
                String name = user.map(User::getName).orElse("<unknown>");
                String marital = user.map(u -> ((Applicant) u).isMarried() ? "Married" : "Single").orElse("?");
                System.out.printf("NRIC: %-10s | Name: %-15s | Project: %-20s | Status: %-12s | Flat: %-6s | Marital: %-7s | Neighbourhood: %-15s%n",
                    a.getApplicantNric(),
                    name,
                    a.getProject().getName(),
                    a.getStatus(),
                    flat,
                    marital,
                    a.getProject().getNeighborhood());
            }
        }

        //16 change password
        private boolean changePasswordFlow(HDBManager m) {
            System.out.print("New password: ");
            m.changePassword(scanner.nextLine());
            try {
                userRepo.addUser(m);     // ensure updated user is stored
                userRepo.saveAll();      // persist to managers.csv
            } catch (IOException e) {
                System.out.println("Failed to save password change.");
            }
            System.out.println("Password changed. Please re-login.");
            return true;
        }

        
       


        // Utility: pick one project that this manager owns
        private Project chooseMyProject(HDBManager m) {
            List<Project> mine = projectSvc.getAllProjects().stream()
                .filter(pj -> m.getNric().equals(pj.getManagerNric()))
                .toList();
            if (mine.isEmpty()) throw new IllegalStateException("No projects.");
            System.out.println("Select project:");
            for (int i = 0; i < mine.size(); i++) {
                System.out.printf("  %d) %s%n", i+1, mine.get(i).getName());
            }
            int idx = Integer.parseInt(scanner.nextLine().trim()) - 1;
            if (idx<0 || idx>=mine.size()) throw new IllegalArgumentException("Invalid choice.");
            return mine.get(idx);
        }
    
  }
